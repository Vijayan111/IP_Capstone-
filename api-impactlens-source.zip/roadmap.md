# API ImpactLens — Roadmap

- [x] Analysis engines: OpenAPI diff, source scanner, faults, risk, fixes, tests, reports, assistant (+ tests)
- [x] Sample assets: api-v1.yaml, api-v2.yaml, sample client app (zip download)
- [x] Design system + app shell (sidebar nav, project switcher, browser-only storage)
- [x] Pages: Overview, API Comparison, Dependency Map, Risk, Faults & Fixes, Regression Tests, Reports, Assistant
- [x] Head metadata per page, verify in browser, commit

Not possible here: VS Code extension (outside web app scope).
