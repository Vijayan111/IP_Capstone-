<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- All analysis (spec diff, source scan, faults, risk, fixes, tests, reports, assistant) lives as pure functions in `src/lib/analysis/` and runs in the browser; keep it framework-free so it stays unit-testable (`src/lib/analysis/__tests__`).
- Projects persist in browser `localStorage` via `src/lib/workspace.tsx` (no sign-in, no server); derived analysis is recomputed with `useAnalysis()`, never stored.
- Sample assets live in root `samples/` (outside `src/` so they aren't typechecked) and are imported with `?raw` / `import.meta.glob`.
- Client source is parsed with `@babel/parser` (not the TypeScript compiler) to keep the browser bundle small; heavy libs (cytoscape, jszip) are dynamically imported.
- React contexts live in their own `*-context.ts` module and component files export only components (helpers like NAV/renderTicks get separate files), so Fast Refresh never recreates a context and orphans its provider.
- Lazily imported deps are listed in `vite.config.ts` `optimizeDeps.include` so the dev server never re-optimizes mid-session (that loads a second React copy).
