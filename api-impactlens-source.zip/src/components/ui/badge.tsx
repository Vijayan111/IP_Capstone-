import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
        secondary:
          "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive:
          "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
        outline: "text-foreground",
        critical: "border-sev-critical/40 bg-sev-critical/15 text-sev-critical uppercase tracking-wider font-mono text-[10px]",
        high: "border-sev-high/40 bg-sev-high/15 text-sev-high uppercase tracking-wider font-mono text-[10px]",
        medium: "border-sev-medium/40 bg-sev-medium/15 text-sev-medium uppercase tracking-wider font-mono text-[10px]",
        low: "border-sev-low/40 bg-sev-low/15 text-sev-low uppercase tracking-wider font-mono text-[10px]",
        info: "border-info/40 bg-info/10 text-info font-mono text-[10px] uppercase tracking-wider",
        muted: "border-border bg-muted text-muted-foreground font-mono text-[10px] uppercase tracking-wider",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
