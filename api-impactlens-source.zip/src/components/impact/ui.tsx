import { Link } from "@tanstack/react-router";
import { Check, Copy } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Severity } from "@/lib/analysis/types";
import { copyText } from "@/lib/download";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/lib/workspace-context";

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow: string; title: string; description?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <p className="eyebrow mb-2">{eyebrow}</p>
        <h1 className="text-3xl font-semibold sm:text-4xl">{title}</h1>
        {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <Badge variant={severity}>{severity}</Badge>;
}

const METHOD_STYLES: Record<string, string> = {
  GET: "text-info border-info/40",
  POST: "text-success border-success/40",
  PUT: "text-sev-medium border-sev-medium/40",
  PATCH: "text-sev-medium border-sev-medium/40",
  DELETE: "text-sev-critical border-sev-critical/40",
};

export function MethodTag({ method }: { method: string }) {
  return <span className={cn("inline-flex min-w-[54px] justify-center rounded border px-1.5 py-0.5 font-mono text-[10px] font-semibold", METHOD_STYLES[method] ?? "border-border text-muted-foreground")}>{method}</span>;
}

export function StatCard({ label, value, hint, tone = "default" }: { label: string; value: ReactNode; hint?: ReactNode; tone?: "default" | "critical" | "signal" | "low" }) {
  return (
    <div className="panel p-5">
      <p className="eyebrow text-muted-foreground">{label}</p>
      <p className={cn("mt-2 font-mono text-3xl font-semibold", tone === "critical" && "text-sev-critical", tone === "signal" && "text-primary", tone === "low" && "text-sev-low")}>{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <Button
      variant="panel"
      size="sm"
      onClick={async () => {
        await copyText(text);
        setDone(true);
        setTimeout(() => setDone(false), 1500);
      }}
    >
      {done ? <Check /> : <Copy />}
      {done ? "Copied" : label}
    </Button>
  );
}

export function CodeBlock({ code, startLine = 1, highlight, diff = false, className }: { code: string; startLine?: number; highlight?: number; diff?: boolean; className?: string }) {
  const lines = code.split("\n");
  return (
    <div className={cn("code-surface overflow-auto", className)}>
      <pre className="min-w-max py-3">
        {lines.map((line, i) => {
          const n = startLine + i;
          const tone = diff
            ? line.startsWith("+") && !line.startsWith("+++")
              ? "bg-diff-add/10 text-diff-add"
              : line.startsWith("-") && !line.startsWith("---")
                ? "bg-diff-del/10 text-diff-del"
                : line.startsWith("@@")
                  ? "text-info"
                  : ""
            : n === highlight
              ? "bg-primary/10"
              : "";
          return (
            <div key={i} className={cn("flex px-3", tone)}>
              {!diff && <span className="mr-4 w-8 shrink-0 select-none text-right text-muted-foreground/50">{n}</span>}
              <code className="whitespace-pre">{line || " "}</code>
            </div>
          );
        })}
      </pre>
    </div>
  );
}

export function EmptyState({ title, body, to, cta }: { title: string; body: string; to?: string; cta?: string }) {
  return (
    <div className="panel flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-4 grid size-12 place-items-center rounded-full border border-dashed border-primary/50">
        <span className="size-2 rounded-full bg-primary" />
      </div>
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mt-1 max-w-md text-sm text-muted-foreground">{body}</p>
      {to && cta && (
        <Button asChild variant="signal" className="mt-5">
          <Link to={to}>{cta}</Link>
        </Button>
      )}
    </div>
  );
}

/** Renders children only once the browser workspace has loaded. */
export function WorkspaceGate({ children }: { children: ReactNode }) {
  const { ready, active } = useWorkspace();
  if (!ready) {
    return (
      <div className="space-y-4">
        <div className="h-10 w-64 animate-pulse rounded bg-muted" />
        <div className="h-48 animate-pulse rounded-xl bg-muted" />
      </div>
    );
  }
  if (!active) return <EmptyState title="No project yet" body="Create a project on the overview page to start analysing an API release." to="/" cta="Go to overview" />;
  return <>{children}</>;
}
