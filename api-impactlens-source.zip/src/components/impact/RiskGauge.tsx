import type { RiskLevel } from "@/lib/analysis/types";
import { cn } from "@/lib/utils";

const TONE: Record<RiskLevel, string> = {
  Critical: "text-sev-critical",
  High: "text-sev-high",
  Medium: "text-sev-medium",
  Low: "text-sev-low",
};

export function RiskGauge({ score, level, size = 200 }: { score: number; level: RiskLevel; size?: number }) {
  const r = 80;
  const c = Math.PI * r; // half circle
  const pct = Math.max(0, Math.min(100, score)) / 100;
  return (
    <div className="relative" style={{ width: size, height: size * 0.62 }}>
      <svg viewBox="0 0 200 120" className="w-full" role="img" aria-label={`Risk score ${score} of 100, ${level}`}>
        <path d="M20 105 A80 80 0 0 1 180 105" fill="none" stroke="currentColor" strokeWidth="14" strokeLinecap="round" className="text-muted" />
        <path
          d="M20 105 A80 80 0 0 1 180 105"
          fill="none"
          stroke="currentColor"
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={`${c * pct} ${c}`}
          className={cn(TONE[level], "transition-all duration-700")}
        />
        {[0, 25, 50, 75, 100].map((t) => {
          const ang = Math.PI * (1 - t / 100);
          return <line key={t} x1={100 + Math.cos(ang) * 64} y1={105 - Math.sin(ang) * 64} x2={100 + Math.cos(ang) * 58} y2={105 - Math.sin(ang) * 58} stroke="currentColor" className="text-muted-foreground/50" strokeWidth="1.5" />;
        })}
      </svg>
      <div className="absolute inset-x-0 bottom-0 text-center">
        <div className="font-mono text-5xl font-semibold leading-none">{score}</div>
        <div className={cn("eyebrow mt-1.5", TONE[level])}>{level} risk</div>
      </div>
    </div>
  );
}
