import { useEffect, useRef } from "react";
import type { ApiReference, Fault, SymbolUsage } from "@/lib/analysis/types";

function cssColor(varName: string): string {
  const raw = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 1;
  const ctx = canvas.getContext("2d");
  if (!ctx || !raw) return "#888888";
  ctx.fillStyle = raw;
  ctx.fillRect(0, 0, 1, 1);
  const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
  return `rgb(${r}, ${g}, ${b})`;
}

interface GNode {
  id: string;
  label: string;
  kind: "endpoint" | "function" | "component" | "hook";
  file?: string;
  broken: number;
}

/** Layered layout: components → hooks/services → endpoints, left to right. */
export default function DependencyGraph({ references, usages, faults, onSelect }: { references: ApiReference[]; usages: SymbolUsage[]; faults: Fault[]; onSelect?: (label: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let destroyed = false;
    let cy: { destroy: () => void } | null = null;
    (async () => {
      const { default: cytoscape } = await import("cytoscape");
      if (destroyed || !ref.current) return;
      const C = {
        endpoint: cssColor("--info"),
        broken: cssColor("--sev-critical"),
        fn: cssColor("--primary"),
        component: cssColor("--success"),
        hook: cssColor("--sev-medium"),
        edge: cssColor("--border"),
        hot: cssColor("--sev-high"),
        text: cssColor("--foreground"),
        muted: cssColor("--muted-foreground"),
      };
      const brokenEndpoints = new Set(faults.map((f) => `${f.reference.method} ${f.reference.path}`));
      const brokenSymbols = new Set(faults.map((f) => `${f.reference.file}#${f.reference.symbol}`));
      const nodes = new Map<string, GNode>();
      const edges: { source: string; target: string; hot: boolean }[] = [];
      const symbolId = new Map<string, string>();
      const kindOf = (k: string): GNode["kind"] => (k === "component" || k === "hook" ? k : "function");

      for (const r of references) {
        const sid = `sym:${r.file}#${r.symbol}`;
        symbolId.set(r.symbol, sid);
        nodes.set(sid, { id: sid, label: r.symbol, kind: kindOf(r.symbolKind), file: r.file.split("/").pop()!, broken: brokenSymbols.has(`${r.file}#${r.symbol}`) ? 1 : 0 });
        const ek = `${r.method} ${r.path}`;
        nodes.set(`ep:${ek}`, { id: `ep:${ek}`, label: ek, kind: "endpoint", broken: brokenEndpoints.has(ek) ? 1 : 0 });
        edges.push({ source: sid, target: `ep:${ek}`, hot: brokenEndpoints.has(ek) });
      }
      for (const u of usages) {
        const target = symbolId.get(u.callee);
        if (!target) continue;
        const cid = `sym:${u.file}#${u.caller}`;
        if (!nodes.has(cid)) nodes.set(cid, { id: cid, label: u.caller, kind: kindOf(u.callerKind), file: u.file.split("/").pop()!, broken: 0 });
        if (cid !== target) edges.push({ source: cid, target, hot: nodes.get(target)?.broken === 1 });
      }

      // Depth = distance from endpoints (endpoints 0, api callers 1, their callers 2, ...)
      const depth = new Map<string, number>();
      for (const n of nodes.values()) if (n.kind === "endpoint") depth.set(n.id, 0);
      for (let pass = 0; pass < 6; pass++) {
        for (const e of edges) {
          const d = depth.get(e.target);
          if (d !== undefined) depth.set(e.source, Math.max(depth.get(e.source) ?? 0, d + 1));
        }
      }
      const maxDepth = Math.max(1, ...depth.values());
      const columns = new Map<number, GNode[]>();
      for (const n of nodes.values()) {
        const col = maxDepth - (depth.get(n.id) ?? 1);
        columns.set(col, [...(columns.get(col) ?? []), n]);
      }
      const width = ref.current.clientWidth || 900;
      const colGap = Math.max(180, (width - 160) / Math.max(1, maxDepth));
      const positions = new Map<string, { x: number; y: number }>();
      for (const [col, list] of columns) {
        list.sort((a, b) => (a.file ?? a.label).localeCompare(b.file ?? b.label) || a.label.localeCompare(b.label));
        list.forEach((n, i) => positions.set(n.id, { x: 80 + col * colGap, y: 40 + i * 56 - ((list.length - 1) * 56) / 2 }));
      }

      cy = cytoscape({
        container: ref.current,
        elements: [
          ...[...nodes.values()].map((n) => ({
            data: { id: n.id, label: n.file ? `${n.label}\n${n.file}` : n.label, name: n.label, kind: n.kind, broken: n.broken },
            position: positions.get(n.id)!,
          })),
          ...edges.map((e, i) => ({ data: { id: `e${i}`, source: e.source, target: e.target, hot: e.hot ? 1 : 0 } })),
        ],
        layout: { name: "preset", fit: true, padding: 40 },
        wheelSensitivity: 0.25,
        minZoom: 0.3,
        maxZoom: 2.5,
        style: [
          { selector: "node", style: { label: "data(label)", color: C.text, "font-size": 10, "font-family": "JetBrains Mono, monospace", "text-wrap": "wrap", "text-valign": "center", "text-halign": "right", "text-margin-x": 8, width: 16, height: 16, "background-color": C.fn } },
          { selector: 'node[kind="endpoint"]', style: { shape: "round-rectangle", width: 22, height: 14, "background-color": C.endpoint } },
          { selector: 'node[kind="endpoint"][broken = 1]', style: { "background-color": C.broken, "underlay-color": C.broken, "underlay-opacity": 0.25, "underlay-padding": 5 } as never },
          { selector: 'node[kind="component"]', style: { shape: "hexagon", "background-color": C.component } },
          { selector: 'node[kind="hook"]', style: { shape: "diamond", "background-color": C.hook } },
          { selector: 'node[kind!="endpoint"][broken = 1]', style: { "border-width": 2, "border-color": C.broken } },
          { selector: "edge", style: { width: 1.2, "line-color": C.edge, "target-arrow-color": C.edge, "target-arrow-shape": "triangle", "curve-style": "unbundled-bezier", "arrow-scale": 0.8 } as never },
          { selector: "edge[hot = 1]", style: { "line-color": C.hot, "target-arrow-color": C.hot, "line-opacity": 0.7 } },
          { selector: "node:selected", style: { "border-width": 3, "border-color": C.fn } },
        ],
      });
      (cy as unknown as { on: (e: string, s: string, cb: (ev: { target: { data: (k: string) => string } }) => void) => void }).on("tap", "node", (ev) => onSelect?.(ev.target.data("name")));
    })();
    return () => {
      destroyed = true;
      cy?.destroy();
    };
  }, [references, usages, faults, onSelect]);

  return <div ref={ref} className="h-[560px] w-full" aria-label="Interactive dependency graph" />;
}
