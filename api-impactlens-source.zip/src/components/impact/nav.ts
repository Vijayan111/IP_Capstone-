import {
  Activity,
  Bot,
  FileText,
  FlaskConical,
  GitCompareArrows,
  LayoutDashboard,
  Network,
  Wrench,
} from "lucide-react";

export const NAV = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/compare", label: "API Comparison", icon: GitCompareArrows },
  { to: "/dependencies", label: "Dependency Map", icon: Network },
  { to: "/risk", label: "Risk Intelligence", icon: Activity },
  { to: "/faults", label: "Faults & Fixes", icon: Wrench },
  { to: "/tests", label: "Regression Tests", icon: FlaskConical },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/assistant", label: "Assistant", icon: Bot },
] as const;
