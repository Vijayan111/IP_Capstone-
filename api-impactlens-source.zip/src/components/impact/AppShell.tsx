import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { NAV } from "./nav";
import { useWorkspace } from "@/lib/workspace-context";
import { cn } from "@/lib/utils";



export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="relative grid size-8 place-items-center overflow-hidden rounded-md border border-primary/40 bg-primary/10">
        <span className="size-3 rounded-full border-2 border-primary" />
        <span className="animate-scan absolute inset-x-0 h-1/2 bg-gradient-to-b from-transparent to-primary/30" />
      </span>
      <span className="font-display text-[17px] font-semibold tracking-tight">
        Impact<span className="text-primary">Lens</span>
      </span>
    </Link>
  );
}

function ProjectSwitcher() {
  const { projects, active, setActiveId, ready } = useWorkspace();
  if (!ready) return <div className="h-9 rounded-md bg-sidebar-accent" />;
  return (
    <label className="block">
      <span className="eyebrow mb-1.5 block text-muted-foreground">Project</span>
      <select
        aria-label="Active project"
        value={active?.id ?? ""}
        onChange={(e) => setActiveId(e.target.value)}
        className="h-9 w-full rounded-md border border-sidebar-border bg-sidebar-accent px-2 text-sm text-sidebar-foreground focus:outline-none focus:ring-1 focus:ring-ring"
      >
        {projects.length === 0 && <option value="">No projects</option>}
        {projects.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </select>
    </label>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[248px_1fr]">
      <aside className="hidden border-r border-sidebar-border bg-sidebar lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col">
        <div className="px-5 pb-5 pt-6">
          <Logo />
        </div>
        <div className="px-4 pb-4">
          <ProjectSwitcher />
        </div>
        <nav className="flex-1 space-y-0.5 px-3" aria-label="Main">
          {NAV.map(({ to, label, icon: Icon }) => {
            const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
            return (
              <Link
                key={to}
                to={to}
                className={cn(
                  "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                  active ? "bg-sidebar-accent text-primary" : "text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                <Icon className={cn("size-4", active ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                {label}
                {active && <span className="ml-auto size-1.5 rounded-full bg-primary" />}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border px-5 py-4 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          v1.0 · runs in your browser
        </div>
      </aside>

      <header className="sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur lg:hidden">
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <Logo />
          <div className="w-44">
            <ProjectSwitcher />
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-2" aria-label="Main mobile">
          {NAV.map(({ to, label }) => {
            const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
            return (
              <Link key={to} to={to} className={cn("whitespace-nowrap rounded-md px-3 py-1.5 text-xs", active ? "bg-accent text-primary" : "text-muted-foreground")}>
                {label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="blueprint min-w-0">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-8 lg:py-10">{children}</div>
      </main>
    </div>
  );
}
