import { SAMPLE_CLIENT_FILES, SAMPLE_V1, SAMPLE_V2 } from "./samples";
import { newId, type Project } from "./workspace-context";

export function makeSampleProject(): Project {
  return {
    id: newId(),
    name: "Billing & User Management",
    createdAt: new Date().toISOString(),
    oldSpec: { name: "api-v1.yaml", text: SAMPLE_V1 },
    newSpec: { name: "api-v2.yaml", text: SAMPLE_V2 },
    source: { label: "sample-client-app.zip", files: SAMPLE_CLIENT_FILES },
    chat: [],
  };
}
