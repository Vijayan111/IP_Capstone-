import { useMemo } from "react";
import { compareSpecs, listEndpoints, parseSpec, type EndpointSummary, type OpenApiSpec } from "./analysis/openapi";
import { analyzeSource } from "./analysis/sourceAnalyzer";
import { detectFaults } from "./analysis/faultDetector";
import { computeRisk } from "./analysis/riskEngine";
import type { ApiChange, Fault, RiskAssessment, SourceAnalysis } from "./analysis/types";
import { useWorkspace, type SpecInput } from "./workspace-context";

export interface Analysis {
  oldSpec: OpenApiSpec | null;
  newSpec: OpenApiSpec | null;
  oldError: string | null;
  newError: string | null;
  hasSpecs: boolean;
  changes: ApiChange[];
  breaking: ApiChange[];
  endpoints: EndpointSummary[];
  source: SourceAnalysis | null;
  faults: Fault[];
  risk: RiskAssessment | null;
}

function tryParse(input: SpecInput | null): { spec: OpenApiSpec | null; error: string | null } {
  if (!input) return { spec: null, error: null };
  try {
    return { spec: parseSpec(input.text), error: null };
  } catch (e) {
    return { spec: null, error: (e as Error).message };
  }
}

export function useAnalysis(): Analysis {
  const { active } = useWorkspace();
  const oldSpecInput = active?.oldSpec ?? null;
  const newSpecInput = active?.newSpec ?? null;
  const sourceFiles = active?.source?.files ?? null;

  const specs = useMemo(() => {
    const o = tryParse(oldSpecInput);
    const n = tryParse(newSpecInput);
    const changes = o.spec && n.spec ? compareSpecs(o.spec, n.spec) : [];
    return { o, n, changes, endpoints: n.spec ? listEndpoints(n.spec) : [] };
  }, [oldSpecInput, newSpecInput]);

  const source = useMemo(() => (sourceFiles ? analyzeSource(sourceFiles) : null), [sourceFiles]);

  return useMemo(() => {
    const { o, n, changes, endpoints } = specs;
    const paths = [...new Set([...Object.keys(o.spec?.paths ?? {}), ...Object.keys(n.spec?.paths ?? {})])];
    const faults = source ? detectFaults(changes, source.references, source.usages, paths) : [];
    const hasSpecs = Boolean(o.spec && n.spec);
    return {
      oldSpec: o.spec,
      newSpec: n.spec,
      oldError: o.error,
      newError: n.error,
      hasSpecs,
      changes,
      breaking: changes.filter((c) => c.breaking),
      endpoints,
      source,
      faults,
      risk: hasSpecs ? computeRisk(changes, faults, source) : null,
    };
  }, [specs, source]);
}
