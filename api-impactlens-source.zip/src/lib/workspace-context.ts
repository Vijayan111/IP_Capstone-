import { createContext, useContext } from "react";
import type { SourceFile } from "./analysis/types";

export interface SpecInput {
  name: string;
  text: string;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  at: string;
}

export interface Project {
  id: string;
  name: string;
  createdAt: string;
  oldSpec: SpecInput | null;
  newSpec: SpecInput | null;
  source: { label: string; files: SourceFile[] } | null;
  chat: ChatMessage[];
}

export interface WorkspaceValue {
  ready: boolean;
  projects: Project[];
  active: Project | null;
  setActiveId: (id: string) => void;
  createProject: (name: string) => Project;
  createSampleProject: () => Project;
  deleteProject: (id: string) => void;
  updateActive: (patch: Partial<Omit<Project, "id">>) => void;
}

// Kept in its own module so hot reloads of the provider never create a second context.
export const WorkspaceContext = createContext<WorkspaceValue | null>(null);

export function useWorkspace() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error("useWorkspace must be used inside WorkspaceProvider");
  return ctx;
}

const uid = () => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `p-${Date.now()}-${Math.random().toString(16).slice(2)}`);
export const newId = uid;
