import type { ApiChange, Fault, RiskAssessment } from "./types";

export type ReportFormat = "markdown" | "html" | "json";

export interface ReportInput {
  projectName: string;
  generatedAt: string;
  oldSpecTitle: string;
  newSpecTitle: string;
  changes: ApiChange[];
  faults: Fault[];
  risk: RiskAssessment;
  filesScanned: number;
  referencesFound: number;
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const md = (s: string) => s.replace(/\|/g, "\\|");

function summary(r: ReportInput) {
  const breaking = r.changes.filter((c) => c.breaking).length;
  return `Comparing ${r.oldSpecTitle} → ${r.newSpecTitle}, ImpactLens found ${r.changes.length} change(s), ${breaking} of them breaking. Scanning ${r.filesScanned} client file(s) (${r.referencesFound} API call sites) revealed ${r.faults.length} potential fault(s) across ${r.risk.blastRadius.files} file(s). Overall release risk is ${r.risk.level} (${r.risk.score}/100).`;
}

export function generateReport(r: ReportInput, format: ReportFormat): string {
  if (format === "json") {
    return JSON.stringify(
      {
        project: r.projectName,
        generatedAt: r.generatedAt,
        specs: { previous: r.oldSpecTitle, updated: r.newSpecTitle },
        summary: summary(r),
        risk: r.risk,
        changes: r.changes,
        faults: r.faults.map((f) => ({ id: f.id, confidence: f.confidence, message: f.message, file: f.reference.file, line: f.reference.line, symbol: f.reference.symbol, change: f.change.id, replacement: f.replacement })),
      },
      null,
      2,
    );
  }
  const breaking = r.changes.filter((c) => c.breaking);
  if (format === "markdown") {
    const lines = [
      `# API Impact Report — ${r.projectName}`,
      "",
      `_Generated ${r.generatedAt} by API ImpactLens_`,
      "",
      "## Executive summary",
      "",
      summary(r),
      "",
      `**Risk score:** ${r.risk.score}/100 (${r.risk.level})`,
      "",
      "| Factor | Score | Basis |",
      "|---|---|---|",
      ...r.risk.factors.map((f) => `| ${f.label} | ${f.score}/${f.max} | ${md(f.explanation)} |`),
      "",
      `> ${r.risk.formula}`,
      "",
      "## Breaking changes",
      "",
      breaking.length ? "| Severity | Endpoint | Location | Description |\n|---|---|---|---|\n" + breaking.map((c) => `| ${c.severity} | \`${c.method} ${c.path}\` | ${md(c.location)} | ${md(c.description)} |`).join("\n") : "None.",
      "",
      "## Blast radius",
      "",
      `- Affected files: ${r.risk.blastRadius.files}`,
      `- Affected symbols: ${r.risk.blastRadius.symbols}`,
      `- Affected endpoints: ${r.risk.blastRadius.endpoints}`,
      "",
      "## Client faults",
      "",
      r.faults.length ? r.faults.map((f) => `- **${f.confidence}** — \`${f.reference.file}:${f.reference.line}\` (${f.reference.symbol}): ${f.message}`).join("\n") : "No client faults detected.",
      "",
      "## High-risk endpoints",
      "",
      ...r.risk.highRiskEndpoints.map((e) => `- \`${e.method} ${e.path}\` — score ${e.score}, ${e.changes} change(s), ${e.faults} fault(s)`),
      "",
      "## Remediation plan",
      "",
      ...r.risk.recommendations.map((x, i) => `${i + 1}. ${x}`),
      "",
    ];
    return lines.join("\n");
  }
  const sevColor: Record<string, string> = { critical: "#d6453d", high: "#e8823a", medium: "#d9b23a", low: "#4ba27a" };
  const row = (c: ApiChange) => `<tr><td><span class="sev" style="background:${sevColor[c.severity]}">${c.severity}</span></td><td><code>${esc(c.method)} ${esc(c.path)}</code></td><td>${esc(c.location)}</td><td>${esc(c.description)}</td></tr>`;
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>API Impact Report — ${esc(r.projectName)}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;margin:0;background:#f6f5f1;color:#1c1e22}
main{max-width:920px;margin:0 auto;padding:48px 24px}
h1{font-size:28px;margin:0 0 4px}h2{font-size:18px;margin:36px 0 12px;border-bottom:1px solid #ddd;padding-bottom:6px}
.meta{color:#666;font-size:13px}.score{display:flex;gap:24px;align-items:center;background:#1c1e22;color:#fff;border-radius:12px;padding:20px 24px;margin:24px 0}
.score b{font-size:48px;font-family:ui-monospace,monospace}.level{font-size:14px;text-transform:uppercase;letter-spacing:.1em;color:#f2b84b}
table{width:100%;border-collapse:collapse;font-size:14px;background:#fff}td,th{text-align:left;padding:8px 10px;border-bottom:1px solid #eee;vertical-align:top}
code{font-family:ui-monospace,monospace;font-size:13px}.sev{color:#fff;border-radius:4px;padding:2px 6px;font-size:11px;text-transform:uppercase}
.bar{height:8px;background:#e5e3dc;border-radius:4px;overflow:hidden}.bar i{display:block;height:100%;background:#e8823a}
li{margin:6px 0}
</style></head><body><main>
<h1>API Impact Report — ${esc(r.projectName)}</h1>
<div class="meta">Generated ${esc(r.generatedAt)} · ${esc(r.oldSpecTitle)} → ${esc(r.newSpecTitle)}</div>
<div class="score"><b>${r.risk.score}</b><div><div class="level">${r.risk.level} risk</div><div>${esc(r.risk.formula)}</div></div></div>
<h2>Executive summary</h2><p>${esc(summary(r))}</p>
<h2>Risk breakdown</h2><table>${r.risk.factors.map((f) => `<tr><td style="width:180px">${esc(f.label)}</td><td style="width:80px"><code>${f.score}/${f.max}</code></td><td><div class="bar"><i style="width:${(f.score / f.max) * 100}%"></i></div><div class="meta">${esc(f.explanation)}</div></td></tr>`).join("")}</table>
<h2>Breaking changes (${breaking.length})</h2>${breaking.length ? `<table><tr><th>Severity</th><th>Endpoint</th><th>Location</th><th>Description</th></tr>${breaking.map(row).join("")}</table>` : "<p>None.</p>"}
<h2>Blast radius</h2><p>${r.risk.blastRadius.files} file(s), ${r.risk.blastRadius.symbols} symbol(s), ${r.risk.blastRadius.endpoints} endpoint(s) affected.</p>
<h2>Client faults (${r.faults.length})</h2>${r.faults.length ? `<ul>${r.faults.map((f) => `<li><b>${f.confidence}</b> — <code>${esc(f.reference.file)}:${f.reference.line}</code> ${esc(f.message)}</li>`).join("")}</ul>` : "<p>No client faults detected.</p>"}
<h2>Remediation plan</h2><ol>${r.risk.recommendations.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>
</main></body></html>`;
}
