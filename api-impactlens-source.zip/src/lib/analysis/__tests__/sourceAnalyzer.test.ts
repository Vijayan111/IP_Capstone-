import { describe, expect, it } from "vitest";
import { analyzeSource, checkPath } from "../sourceAnalyzer";

describe("source analyzer", () => {
  it("detects fetch & Axios references with locations", () => {
    const { references } = analyzeSource([
      {
        path: "src/api.ts",
        content: [
          'import axios from "axios";',
          'const BASE = "https://api.example.com/v1";',
          "export async function load(id: string) {",
          "  await fetch(`${BASE}/users/${id}`);",
          '  await axios.post("/orders", { a: 1 });',
          '  await fetch("/invoices?status=open", { method: "DELETE" });',
          "}",
        ].join("\n"),
      },
    ]);
    expect(references.map((r) => [r.method, r.path, r.line, r.callType])).toEqual([
      ["GET", "/v1/users/{param}", 4, "fetch"],
      ["POST", "/orders", 5, "axios"],
      ["DELETE", "/invoices", 6, "fetch"],
    ]);
    expect(references[2]?.queryParams).toEqual(["status"]);
    expect(references[0]?.symbol).toBe("load");
  });

  it("detects API client calls inside React components", () => {
    const { references, usages } = analyzeSource([
      {
        path: "src/Profile.tsx",
        content: [
          "export function Profile() {",
          "  useEffect(() => { api.get('/me').then(r => setName(r.data.displayName)); }, []);",
          "  return <div>{name}</div>;",
          "}",
          "export function Page() { loadOrders(); return <Profile />; }",
          "export const loadOrders = () => fetch('/orders');",
        ].join("\n"),
      },
    ]);
    const me = references.find((r) => r.path === "/me");
    expect(me?.symbolKind).toBe("component");
    expect(me?.symbol).toBe("Profile");
    expect(me?.fieldsUsed).toContain("displayName");
    expect(usages).toEqual([expect.objectContaining({ caller: "Page", callee: "loadOrders", callerKind: "component" })]);
  });

  it("rejects unsafe paths, traversal, and unsupported files", () => {
    expect(checkPath("../etc/passwd.ts")).toEqual({ ok: false, reason: "Path traversal is not allowed" });
    expect(checkPath("/abs/file.ts").ok).toBe(false);
    expect(checkPath("C:/win/file.ts").ok).toBe(false);
    expect(checkPath("node_modules/x/index.js").ok).toBe(false);
    expect(checkPath("src/logo.png")).toEqual({ ok: false, reason: "Unsupported file type" });
    expect(checkPath("src/app.tsx")).toEqual({ ok: true });
    const res = analyzeSource([{ path: "src/a/../../b.ts", content: "fetch('/x')" }, { path: "README.md", content: "" }]);
    expect(res.references).toHaveLength(0);
    expect(res.skipped).toHaveLength(2);
  });
});
