import { describe, expect, it } from "vitest";
import { SAMPLE_CLIENT_FILES } from "@/lib/samples";
import { generateFix } from "../codeFixEngine";
import { samplePipeline } from "./pipeline";

describe("code fix engine", () => {
  it("generates before/after code, diffs, and migration steps", () => {
    const { faults } = samplePipeline();
    const content = (file: string) => SAMPLE_CLIENT_FILES.find((f) => f.path === file)!.content;

    const rename = faults.find((f) => f.change.type === "response-field-removed" && f.change.field === "email")!;
    const fix = generateFix(rename, content(rename.reference.file));
    expect(fix.before).toContain("u.email");
    expect(fix.after).toContain("u.contactEmail");
    expect(fix.diff).toContain("+");
    expect(fix.diff).toMatch(/^--- a\/src\/services\/userService.ts/);
    expect(fix.steps.length).toBeGreaterThan(1);

    const limit = faults.find((f) => f.change.field === "limit")!;
    const limitFix = generateFix(limit, content(limit.reference.file));
    expect(limitFix.after).toContain("&limit=${encodeURIComponent(limit)}");
  });
});
