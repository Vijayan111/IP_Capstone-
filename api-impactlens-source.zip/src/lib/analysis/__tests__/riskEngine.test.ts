import { describe, expect, it } from "vitest";
import { computeRisk, levelFor } from "../riskEngine";
import type { ApiChange } from "../types";
import { samplePipeline } from "./pipeline";

const change = (over: Partial<ApiChange>): ApiChange => ({
  id: "c", type: "endpoint-removed", breaking: true, severity: "critical", method: "GET", path: "/a", location: "endpoint", description: "", isPublic: false, ...over,
});

describe("risk engine", () => {
  it("evaluates risk score based on critical breaking changes", () => {
    const one = computeRisk([change({ id: "1" })], []);
    // 1 breaking × 6 = 6, severity critical 10, no blast, no exposure
    expect(one.score).toBe(16);
    expect(one.level).toBe("Low");
    const { changes, faults, source } = samplePipeline();
    const sample = computeRisk(changes, faults, source);
    expect(sample.score).toBeGreaterThanOrEqual(75);
    expect(sample.level).toBe("Critical");
    const scores = sample.highRiskEndpoints.map((e) => e.score);
    expect(scores).toEqual([...scores].sort((a, b) => b - a));
    expect(sample.highRiskEndpoints[0]?.path).toBe("/users");
  });

  it("verifies score caps (0–100) and formula explanation", () => {
    const many = Array.from({ length: 40 }, (_, i) => change({ id: String(i), path: `/p${i}`, isPublic: true }));
    const r = computeRisk(many, []);
    expect(r.factors.map((f) => [f.key, f.score, f.max])).toEqual([
      ["breaking", 40, 40],
      ["severity", 25, 25],
      ["blast", 0, 25],
      ["exposure", 10, 10],
    ]);
    expect(r.score).toBeLessThanOrEqual(100);
    expect(computeRisk([], []).score).toBe(0);
    expect(r.formula).toContain("capped at 100");
    expect(r.factors[0]?.explanation).toContain("40 breaking × 6");
    expect([levelFor(75), levelFor(50), levelFor(25), levelFor(24)]).toEqual(["Critical", "High", "Medium", "Low"]);
  });
});
