import { describe, expect, it } from "vitest";
import { computeRisk } from "../riskEngine";
import { generateReport, type ReportInput } from "../reportGenerator";
import { samplePipeline } from "./pipeline";

describe("report generator", () => {
  it("generates Markdown and self-contained HTML audit reports", () => {
    const { changes, faults, source } = samplePipeline();
    const input: ReportInput = {
      projectName: "Billing <Test>",
      generatedAt: "2026-11-23",
      oldSpecTitle: "v1",
      newSpecTitle: "v2",
      changes,
      faults,
      risk: computeRisk(changes, faults, source),
      filesScanned: source.files.length,
      referencesFound: source.references.length,
    };
    const md = generateReport(input, "markdown");
    expect(md).toContain("# API Impact Report — Billing <Test>");
    expect(md).toContain("## Executive summary");
    expect(md).toContain("## Breaking changes");
    expect(md).toContain("## Remediation plan");
    const html = generateReport(input, "html");
    expect(html.startsWith("<!doctype html>")).toBe(true);
    expect(html).toContain("Billing &lt;Test&gt;");
    expect(html).not.toMatch(/<link|<script/);
    const json = JSON.parse(generateReport(input, "json"));
    expect(json.risk.score).toBe(input.risk.score);
  });
});
