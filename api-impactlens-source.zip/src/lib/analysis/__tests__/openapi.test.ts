import { describe, expect, it } from "vitest";
import { samplePipeline } from "./pipeline";

describe("openapi comparison", () => {
  it("detects breaking parameter & field changes and additions", () => {
    const { changes } = samplePipeline();
    const find = (type: string, path: string, field?: string) =>
      changes.find((c) => c.type === type && c.path === path && (field === undefined || c.field === field));

    expect(find("param-required-added", "/users", "limit")?.breaking).toBe(true);
    expect(find("param-required-added", "/invoices", "X-Tenant-Id")?.paramIn).toBe("header");
    const email = find("response-field-removed", "/users", "email");
    expect(email?.breaking).toBe(true);
    expect(email?.renamedTo).toBe("contactEmail");
    expect(find("response-field-type-changed", "/invoices", "amount")?.after).toBe("string");
    expect(find("method-removed", "/users/{id}")?.method).toBe("DELETE");
    expect(find("endpoint-removed", "/legacy/reports")?.severity).toBe("critical");
    expect(find("enum-value-removed", "/invoices", "status")?.breaking).toBe(true);
    expect(find("request-field-required-added", "/users", "organizationId")?.breaking).toBe(true);
    expect(find("endpoint-added", "/webhooks")?.breaking).toBe(false);
    expect(find("response-field-removed", "/plans", "price")?.isPublic).toBe(true);
  });
});
