import { describe, expect, it } from "vitest";
import { bestSpecMatch, matchRoute } from "../faultDetector";
import { samplePipeline } from "./pipeline";

describe("fault detector", () => {
  it("matches route variations and parameters", () => {
    expect(matchRoute("/users/{param}", "/users/{id}")).toBe(true);
    expect(matchRoute("/v1/users/{param}", "/users/{id}")).toBe(true);
    expect(matchRoute("/users/42", "/users/{id}")).toBe(true);
    expect(matchRoute("/users/{param}", "/users/me")).toBe(false);
    expect(matchRoute("/users", "/users/{id}")).toBe(false);
    expect(bestSpecMatch("/v1/invoices/{param}/pay", ["/invoices", "/invoices/{id}", "/invoices/{id}/pay"])).toBe("/invoices/{id}/pay");
  });

  it("flags source faults when breaking changes affect client code", () => {
    const { faults } = samplePipeline();
    const has = (type: string, file: string, confidence?: string) =>
      faults.some((f) => f.change.type === type && f.reference.file === file && (!confidence || f.confidence === confidence));
    expect(has("response-field-removed", "src/services/userService.ts", "confirmed")).toBe(true);
    expect(has("param-required-added", "src/services/userService.ts", "confirmed")).toBe(true);
    expect(has("method-removed", "src/services/userService.ts", "confirmed")).toBe(true);
    expect(has("endpoint-removed", "src/services/billingService.ts", "confirmed")).toBe(true);
    expect(has("response-field-type-changed", "src/services/billingService.ts", "confirmed")).toBe(true);
    expect(has("response-field-removed", "src/services/plansService.ts", "confirmed")).toBe(true);
    // payInvoice never reads the retyped `amount`, so it is at most a possible fault
    expect(faults.some((f) => f.change.path === "/invoices/{id}/pay" && f.confidence === "confirmed")).toBe(false);
    const legacy = faults.find((f) => f.change.path === "/legacy/reports");
    expect(legacy?.replacement).toBe("GET /reports/exports");
    expect(legacy?.impactedCallers.map((u) => u.caller)).toContain("AdminPanel");
  });
});
