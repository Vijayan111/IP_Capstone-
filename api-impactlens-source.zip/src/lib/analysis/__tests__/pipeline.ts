import { SAMPLE_CLIENT_FILES, SAMPLE_V1, SAMPLE_V2 } from "@/lib/samples";
import { compareSpecs, parseSpec } from "../openapi";
import { analyzeSource } from "../sourceAnalyzer";
import { detectFaults } from "../faultDetector";

export function samplePipeline() {
  const v1 = parseSpec(SAMPLE_V1);
  const v2 = parseSpec(SAMPLE_V2);
  const changes = compareSpecs(v1, v2);
  const source = analyzeSource(SAMPLE_CLIENT_FILES);
  const paths = [...new Set([...Object.keys(v1.paths), ...Object.keys(v2.paths)])];
  const faults = detectFaults(changes, source.references, source.usages, paths);
  return { v1, v2, changes, source, faults };
}
