import { describe, expect, it } from "vitest";
import { listEndpoints } from "../openapi";
import { generateTests } from "../testGenerator";
import { samplePipeline } from "./pipeline";

describe("test generator", () => {
  it("generates Vitest suite asserting status codes & required parameters", () => {
    const { v2, changes } = samplePipeline();
    const code = generateTests({ framework: "vitest", baseUrl: "https://api.example.com/v1", endpoints: listEndpoints(v2), changes });
    expect(code).toContain('import { describe, it, expect } from "vitest";');
    expect(code).toContain('describe("GET /users"');
    expect(code).toContain('call("GET", "/users?limit=25"');
    expect(code).toContain('rejects requests without required query \\"limit\\"');
    expect(code).toContain("expect([400, 422]).toContain(res.status);");
    expect(code).toContain('expect(item).toHaveProperty("contactEmail");');
    expect(code).toContain('it("GET /legacy/reports is gone"');
    const plansOnly = generateTests({ framework: "jest", baseUrl: "http://x", endpoints: listEndpoints(v2), changes: changes.filter((c) => c.path === "/plans") });
    expect(plansOnly).toContain('describe("GET /plans"');
    expect(plansOnly).not.toContain('describe("GET /users"');
    expect(plansOnly).not.toContain('from "vitest"');
  });
});
