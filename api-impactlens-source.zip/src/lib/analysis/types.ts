export type Severity = "critical" | "high" | "medium" | "low";

export type ChangeType =
  | "endpoint-removed"
  | "endpoint-added"
  | "method-removed"
  | "method-added"
  | "param-required-added"
  | "param-optional-added"
  | "param-removed"
  | "param-made-required"
  | "param-type-changed"
  | "enum-value-removed"
  | "request-body-required"
  | "request-field-required-added"
  | "response-status-removed"
  | "response-field-removed"
  | "response-field-added"
  | "response-field-type-changed";

export interface ApiChange {
  id: string;
  type: ChangeType;
  breaking: boolean;
  severity: Severity;
  method: string;
  path: string;
  /** Where in the operation the change lives, e.g. "query.limit" or "response.200.email". */
  location: string;
  /** Leaf name of the affected field or parameter, when relevant. */
  field?: string;
  /** Parameter location for parameter changes (query, header, path, cookie). */
  paramIn?: string;
  description: string;
  before?: string;
  after?: string;
  renamedTo?: string;
  isPublic: boolean;
}

export interface SourceFile {
  path: string;
  content: string;
}

export type SymbolKind = "component" | "hook" | "function" | "module";

export interface ApiReference {
  id: string;
  file: string;
  line: number;
  column: number;
  method: string;
  rawUrl: string;
  path: string;
  symbol: string;
  symbolKind: SymbolKind;
  callType: "fetch" | "axios" | "client";
  fieldsUsed: string[];
  queryParams: string[];
  headers: string[];
  snippet: string;
}

export interface SymbolUsage {
  file: string;
  line: number;
  caller: string;
  callerKind: SymbolKind;
  callee: string;
  callerFields: string[];
}

export interface SourceAnalysis {
  files: { path: string; lines: number; references: number }[];
  references: ApiReference[];
  usages: SymbolUsage[];
  skipped: { path: string; reason: string }[];
  errors: { path: string; message: string }[];
}

export type Confidence = "confirmed" | "possible";

export interface Fault {
  id: string;
  change: ApiChange;
  reference: ApiReference;
  confidence: Confidence;
  message: string;
  impactedCallers: SymbolUsage[];
  replacement?: string;
}

export type RiskLevel = "Critical" | "High" | "Medium" | "Low";

export interface RiskFactor {
  key: "breaking" | "severity" | "blast" | "exposure";
  label: string;
  score: number;
  max: number;
  explanation: string;
}

export interface RiskAssessment {
  score: number;
  level: RiskLevel;
  factors: RiskFactor[];
  formula: string;
  blastRadius: { files: number; symbols: number; endpoints: number; references: number };
  highRiskEndpoints: { method: string; path: string; score: number; changes: number; faults: number; topSeverity: Severity }[];
  recommendations: string[];
  severityCounts: Record<Severity, number>;
}

export interface CodeFix {
  title: string;
  file: string;
  startLine: number;
  before: string;
  after: string;
  diff: string;
  steps: string[];
}
