/* eslint-disable @typescript-eslint/no-explicit-any */
import YAML from "yaml";
import type { ApiChange, ChangeType, Severity } from "./types";

export const HTTP_METHODS = ["get", "put", "post", "delete", "patch", "options", "head"] as const;

export interface OpenApiSpec {
  openapi?: string;
  swagger?: string;
  info?: { title?: string; version?: string; description?: string };
  servers?: { url: string }[];
  paths: Record<string, any>;
  components?: any;
  security?: any;
}

export function parseSpec(text: string): OpenApiSpec {
  const trimmed = text.trim();
  if (!trimmed) throw new Error("The specification is empty.");
  let doc: any;
  try {
    doc = trimmed.startsWith("{") ? JSON.parse(trimmed) : YAML.parse(trimmed);
  } catch (e) {
    throw new Error(`Could not parse the specification: ${(e as Error).message}`);
  }
  if (!doc || typeof doc !== "object") throw new Error("The specification is not an object.");
  if (!doc.openapi && !doc.swagger) throw new Error("Missing an `openapi` version field — is this an OpenAPI document?");
  if (!doc.paths || typeof doc.paths !== "object") throw new Error("The specification has no `paths` section.");
  return doc as OpenApiSpec;
}

function resolveRef(spec: any, value: any, depth = 0): any {
  if (!value || typeof value !== "object" || depth > 20) return value;
  if (typeof value.$ref === "string" && value.$ref.startsWith("#/")) {
    const target = value.$ref
      .slice(2)
      .split("/")
      .reduce((acc: any, key: string) => (acc ? acc[key.replace(/~1/g, "/").replace(/~0/g, "~")] : undefined), spec);
    return resolveRef(spec, target, depth + 1);
  }
  return value;
}

export interface FieldInfo {
  type: string;
  enum?: string[];
  required: boolean;
}

/** Flattens a JSON schema into dotted field paths ("user.email", "items[].id"). */
export function flattenSchema(spec: any, schema: any, prefix = "", out = new Map<string, FieldInfo>(), depth = 0, parentRequired = true): Map<string, FieldInfo> {
  const s = resolveRef(spec, schema);
  if (!s || typeof s !== "object" || depth > 8) return out;
  const combined = [...(s.allOf ?? []), ...(s.oneOf ?? []), ...(s.anyOf ?? [])];
  if (combined.length) {
    for (const part of combined) flattenSchema(spec, part, prefix, out, depth + 1, parentRequired);
  }
  const type = s.type ?? (s.properties ? "object" : s.items ? "array" : combined.length ? "object" : "any");
  if (prefix) {
    const info: FieldInfo = { type: String(type), required: parentRequired };
    if (Array.isArray(s.enum)) info.enum = s.enum.map(String);
    out.set(prefix, info);
  }
  if (type === "array" && s.items) {
    // A top-level array response describes its items directly ("email", not "[].email").
    flattenSchema(spec, s.items, prefix ? `${prefix}[]` : "", out, depth + 1, true);
  }
  if (s.properties) {
    const required: string[] = Array.isArray(s.required) ? s.required : [];
    for (const [key, child] of Object.entries(s.properties)) {
      const p = prefix ? `${prefix}.${key}` : key;
      flattenSchema(spec, child, p, out, depth + 1, required.includes(key));
    }
  }
  return out;
}

export function normalizeTemplatePath(path: string): string {
  return path.replace(/\{[^}]+\}/g, "{}").replace(/\/+$/, "") || "/";
}

function collectParams(spec: any, pathItem: any, op: any) {
  const map = new Map<string, any>();
  for (const raw of [...(pathItem?.parameters ?? []), ...(op?.parameters ?? [])]) {
    const p = resolveRef(spec, raw);
    if (!p?.name || !p?.in) continue;
    map.set(`${p.in}:${p.name}`, { ...p, schema: resolveRef(spec, p.schema) });
  }
  return map;
}

function jsonSchemaOf(spec: any, container: any) {
  const c = resolveRef(spec, container);
  const content = c?.content;
  if (!content) return c?.schema;
  const key = Object.keys(content).find((k) => k.includes("json")) ?? Object.keys(content)[0];
  return key ? content[key]?.schema : undefined;
}

function isOperationPublic(spec: any, op: any): boolean {
  const security = op?.security ?? spec.security;
  if (!security) return true;
  if (Array.isArray(security) && security.length === 0) return true;
  return Array.isArray(security) && security.some((s: any) => s && Object.keys(s).length === 0);
}

const SEVERITY: Record<ChangeType, { breaking: boolean; severity: Severity }> = {
  "endpoint-removed": { breaking: true, severity: "critical" },
  "method-removed": { breaking: true, severity: "critical" },
  "endpoint-added": { breaking: false, severity: "low" },
  "method-added": { breaking: false, severity: "low" },
  "param-required-added": { breaking: true, severity: "high" },
  "param-made-required": { breaking: true, severity: "high" },
  "param-optional-added": { breaking: false, severity: "low" },
  "param-removed": { breaking: false, severity: "low" },
  "param-type-changed": { breaking: true, severity: "medium" },
  "enum-value-removed": { breaking: true, severity: "medium" },
  "request-body-required": { breaking: true, severity: "high" },
  "request-field-required-added": { breaking: true, severity: "high" },
  "response-status-removed": { breaking: true, severity: "high" },
  "response-field-removed": { breaking: true, severity: "high" },
  "response-field-added": { breaking: false, severity: "low" },
  "response-field-type-changed": { breaking: true, severity: "high" },
};

const leaf = (p: string) => p.split(".").pop()!.replace(/\[\]$/, "");
const parentOf = (p: string) => (p.includes(".") ? p.slice(0, p.lastIndexOf(".")) : "");

/** Semantic comparison of two OpenAPI documents. */
export function compareSpecs(oldSpec: OpenApiSpec, newSpec: OpenApiSpec): ApiChange[] {
  const changes: ApiChange[] = [];
  let counter = 0;
  const push = (type: ChangeType, method: string, path: string, isPublic: boolean, extra: Partial<ApiChange> & { location: string; description: string }) => {
    const meta = SEVERITY[type];
    const change: ApiChange = { id: `chg-${++counter}`, type, ...meta, method: method.toUpperCase(), path, isPublic, ...extra } as ApiChange;
    changes.push(change);
  };

  const newPathIndex = new Map<string, string>();
  for (const p of Object.keys(newSpec.paths)) newPathIndex.set(normalizeTemplatePath(p), p);
  const oldPathIndex = new Map<string, string>();
  for (const p of Object.keys(oldSpec.paths)) oldPathIndex.set(normalizeTemplatePath(p), p);

  for (const [oldPath, oldItemRaw] of Object.entries(oldSpec.paths)) {
    const oldItem = resolveRef(oldSpec, oldItemRaw);
    const newPath = newPathIndex.get(normalizeTemplatePath(oldPath));
    const newItem = newPath ? resolveRef(newSpec, newSpec.paths[newPath]) : undefined;
    for (const m of HTTP_METHODS) {
      const oldOp = oldItem?.[m];
      if (!oldOp) continue;
      const isPublic = isOperationPublic(oldSpec, oldOp);
      if (!newItem) {
        push("endpoint-removed", m, oldPath, isPublic, { location: "endpoint", description: `${m.toUpperCase()} ${oldPath} was removed.` });
        continue;
      }
      const newOp = newItem[m];
      if (!newOp) {
        push("method-removed", m, oldPath, isPublic, { location: "method", description: `The ${m.toUpperCase()} method on ${oldPath} was removed.` });
        continue;
      }
      const pub = isPublic || isOperationPublic(newSpec, newOp);
      compareOperation(m, oldPath, oldItem, oldOp, newItem, newOp, pub);
    }
  }

  for (const [newPath, newItemRaw] of Object.entries(newSpec.paths)) {
    const newItem = resolveRef(newSpec, newItemRaw);
    const oldPath = oldPathIndex.get(normalizeTemplatePath(newPath));
    const oldItem = oldPath ? resolveRef(oldSpec, oldSpec.paths[oldPath]) : undefined;
    for (const m of HTTP_METHODS) {
      if (!newItem?.[m]) continue;
      const isPublic = isOperationPublic(newSpec, newItem[m]);
      if (!oldItem) push("endpoint-added", m, newPath, isPublic, { location: "endpoint", description: `New endpoint ${m.toUpperCase()} ${newPath}.` });
      else if (!oldItem[m]) push("method-added", m, newPath, isPublic, { location: "method", description: `New method ${m.toUpperCase()} on ${newPath}.` });
    }
  }

  function compareOperation(m: string, path: string, oldItem: any, oldOp: any, newItem: any, newOp: any, isPublic: boolean) {
    // Parameters
    const oldParams = collectParams(oldSpec, oldItem, oldOp);
    const newParams = collectParams(newSpec, newItem, newOp);
    for (const [key, np] of newParams) {
      const op = oldParams.get(key);
      const loc = `${np.in}.${np.name}`;
      if (!op) {
        if (np.in === "path") continue; // path params follow the path template
        if (np.required) push("param-required-added", m, path, isPublic, { location: loc, field: np.name, paramIn: np.in, description: `New required ${np.in} parameter \`${np.name}\`.`, after: "required" });
        else push("param-optional-added", m, path, isPublic, { location: loc, field: np.name, paramIn: np.in, description: `New optional ${np.in} parameter \`${np.name}\`.` });
        continue;
      }
      if (!op.required && np.required) push("param-made-required", m, path, isPublic, { location: loc, field: np.name, paramIn: np.in, description: `${np.in} parameter \`${np.name}\` is now required.`, before: "optional", after: "required" });
      const ot = op.schema?.type, nt = np.schema?.type;
      if (ot && nt && ot !== nt) push("param-type-changed", m, path, isPublic, { location: loc, field: np.name, paramIn: np.in, description: `Type of \`${np.name}\` changed from ${ot} to ${nt}.`, before: ot, after: nt });
      const oe: string[] | undefined = op.schema?.enum?.map(String), ne: string[] | undefined = np.schema?.enum?.map(String);
      if (oe && ne) {
        const removed = oe.filter((v) => !ne.includes(v));
        if (removed.length) push("enum-value-removed", m, path, isPublic, { location: loc, field: np.name, paramIn: np.in, description: `\`${np.name}\` no longer accepts ${removed.map((v) => `"${v}"`).join(", ")}.`, before: oe.join(" | "), after: ne.join(" | ") });
      }
    }
    for (const [key, op] of oldParams) {
      if (!newParams.has(key) && op.in !== "path") push("param-removed", m, path, isPublic, { location: `${op.in}.${op.name}`, field: op.name, paramIn: op.in, description: `${op.in} parameter \`${op.name}\` was removed (the server will ignore it).` });
    }

    // Request body
    const oldBody = resolveRef(oldSpec, oldOp.requestBody);
    const newBody = resolveRef(newSpec, newOp.requestBody);
    if (newBody?.required && !oldBody?.required) push("request-body-required", m, path, isPublic, { location: "requestBody", description: "A request body is now required." });
    if (newBody) {
      const of = oldBody ? flattenSchema(oldSpec, jsonSchemaOf(oldSpec, oldBody)) : new Map<string, FieldInfo>();
      const nf = flattenSchema(newSpec, jsonSchemaOf(newSpec, newBody));
      for (const [field, info] of nf) {
        if (!info.required || field.includes("[]")) continue;
        const before = of.get(field);
        if (!before || !before.required) push("request-field-required-added", m, path, isPublic, { location: `requestBody.${field}`, field: leaf(field), description: `Request body field \`${field}\` is now required.`, before: before ? "optional" : "absent", after: "required" });
      }
    }

    // Responses
    const oldResponses = oldOp.responses ?? {};
    const newResponses = newOp.responses ?? {};
    for (const status of Object.keys(oldResponses)) {
      if (!/^2/.test(status)) continue;
      if (!newResponses[status]) {
        push("response-status-removed", m, path, isPublic, { location: `response.${status}`, description: `Success response ${status} is no longer returned.`, before: status });
        continue;
      }
      const of = flattenSchema(oldSpec, jsonSchemaOf(oldSpec, oldResponses[status]));
      const nf = flattenSchema(newSpec, jsonSchemaOf(newSpec, newResponses[status]));
      const removed = [...of.keys()].filter((f) => !nf.has(f));
      const added = [...nf.keys()].filter((f) => !of.has(f));
      // Skip children of removed fields to keep the report focused.
      const topRemoved = removed.filter((f) => !removed.some((r) => r !== f && (f.startsWith(`${r}.`) || f.startsWith(`${r}[]`))));
      const topAdded = added.filter((f) => !added.some((a) => a !== f && (f.startsWith(`${a}.`) || f.startsWith(`${a}[]`))));
      const usedAdds = new Set<string>();
      for (const f of topRemoved) {
        const info = of.get(f)!;
        const rename = topAdded.find((a) => !usedAdds.has(a) && parentOf(a) === parentOf(f) && nf.get(a)!.type === info.type);
        if (rename) usedAdds.add(rename);
        push("response-field-removed", m, path, isPublic, {
          location: `response.${status}.${f}`,
          field: leaf(f),
          description: rename ? `Response field \`${f}\` was removed — likely renamed to \`${rename}\`.` : `Response field \`${f}\` was removed.`,
          before: rename ? f : info.type,
          ...(rename ? { renamedTo: leaf(rename), after: rename } : {}),
        });
      }
      for (const f of topAdded) {
        if (usedAdds.has(f)) continue;
        push("response-field-added", m, path, isPublic, { location: `response.${status}.${f}`, field: leaf(f), description: `New response field \`${f}\`.`, after: nf.get(f)!.type });
      }
      for (const [f, info] of of) {
        const n = nf.get(f);
        if (!n) continue;
        if (n.type !== info.type && info.type !== "any" && n.type !== "any") push("response-field-type-changed", m, path, isPublic, { location: `response.${status}.${f}`, field: leaf(f), description: `Response field \`${f}\` changed type from ${info.type} to ${n.type}.`, before: info.type, after: n.type });
      }
    }
  }

  return changes;
}

export interface EndpointSummary {
  method: string;
  path: string;
  summary?: string;
  isPublic: boolean;
  successStatus: string;
  requiredParams: { name: string; in: string; example: string }[];
  requiredResponseFields: string[];
  requestBodyExample?: Record<string, unknown>;
}

function exampleFor(schema: any): string {
  if (!schema) return "1";
  if (schema.example !== undefined) return String(schema.example);
  if (Array.isArray(schema.enum) && schema.enum.length) return String(schema.enum[0]);
  if (schema.type === "integer" || schema.type === "number") return "1";
  if (schema.type === "boolean") return "true";
  if (schema.format === "uuid") return "00000000-0000-0000-0000-000000000001";
  return "sample";
}

export function listEndpoints(spec: OpenApiSpec): EndpointSummary[] {
  const out: EndpointSummary[] = [];
  for (const [path, raw] of Object.entries(spec.paths)) {
    const item = resolveRef(spec, raw);
    for (const m of HTTP_METHODS) {
      const op = item?.[m];
      if (!op) continue;
      const params = collectParams(spec, item, op);
      const statuses = Object.keys(op.responses ?? {});
      const success = statuses.find((s) => /^2/.test(s)) ?? "200";
      const schema = success ? jsonSchemaOf(spec, op.responses?.[success]) : undefined;
      const resolved = resolveRef(spec, schema);
      const objSchema = resolved?.type === "array" ? resolveRef(spec, resolved.items) : resolved;
      const requiredResponseFields: string[] = Array.isArray(objSchema?.required) ? objSchema.required : [];
      const body = resolveRef(spec, op.requestBody);
      let requestBodyExample: Record<string, unknown> | undefined;
      if (body) {
        const bs = resolveRef(spec, jsonSchemaOf(spec, body));
        requestBodyExample = {};
        for (const key of (bs?.required ?? []) as string[]) {
          const ps = resolveRef(spec, bs.properties?.[key]);
          const ex = exampleFor(ps);
          requestBodyExample[key] = ps?.type === "integer" || ps?.type === "number" ? Number(ex) : ex;
        }
      }
      const entry: EndpointSummary = {
        method: m.toUpperCase(),
        path,
        isPublic: isOperationPublic(spec, op),
        successStatus: success,
        requiredParams: [...params.values()].filter((p) => p.required || p.in === "path").map((p) => ({ name: p.name, in: p.in, example: exampleFor(p.schema) })),
        requiredResponseFields,
      };
      if (op.summary) entry.summary = op.summary;
      if (requestBodyExample) entry.requestBodyExample = requestBodyExample;
      out.push(entry);
    }
  }
  return out;
}

export function specTitle(spec: OpenApiSpec | null | undefined): string {
  if (!spec) return "—";
  return `${spec.info?.title ?? "Untitled API"} ${spec.info?.version ? `v${spec.info.version}` : ""}`.trim();
}
