import type { ApiChange, Fault, RiskAssessment, SourceAnalysis } from "./types";

export interface AssistantContext {
  projectName: string;
  changes: ApiChange[];
  faults: Fault[];
  risk: RiskAssessment | null;
  source: SourceAnalysis | null;
}

export const PROMPT_PILLS = [
  "Is it safe to release?",
  "Which files will break?",
  "Explain the risk score",
  "What are the breaking changes?",
  "How do I fix the worst issue?",
  "Which endpoints are public?",
];

const list = (items: string[], max = 6) => items.slice(0, max).map((i) => `• ${i}`).join("\n") + (items.length > max ? `\n…and ${items.length - max} more.` : "");

/** Rule-based assistant that answers from the active project's analysis. */
export function answer(question: string, ctx: AssistantContext): string {
  const q = question.toLowerCase();
  const breaking = ctx.changes.filter((c) => c.breaking);
  if (!ctx.changes.length && !ctx.source?.references.length) {
    return "I don't have anything to analyse yet. Upload a previous and an updated OpenAPI spec in API Comparison, and scan your client code in Dependency Map — then ask me again.";
  }

  const endpointMatch = question.match(/(GET|POST|PUT|PATCH|DELETE)?\s*(\/[\w/{}.-]+)/i);
  if (endpointMatch?.[2]) {
    const path = endpointMatch[2];
    const related = ctx.changes.filter((c) => c.path === path || c.path.startsWith(path));
    const faults = ctx.faults.filter((f) => f.change.path === path || f.change.path.startsWith(path));
    if (related.length) {
      return `Here's what changed on ${path}:\n${list(related.map((c) => `[${c.severity}${c.breaking ? ", breaking" : ""}] ${c.method} — ${c.description}`))}\n\n${faults.length ? `It affects ${faults.length} client call site(s):\n${list(faults.map((f) => `${f.reference.file}:${f.reference.line} (${f.reference.symbol})`))}` : "No client code calls it in the scanned source."}`;
    }
  }

  if (/safe|release|deploy|ship|go live/.test(q)) {
    if (!ctx.risk) return "Upload both specs first so I can score the release.";
    const verdict = ctx.risk.level === "Low" ? "Yes — this looks safe to release." : ctx.risk.level === "Medium" ? "Probably, with care." : "Not yet.";
    return `${verdict} The release scores ${ctx.risk.score}/100 (${ctx.risk.level}) with ${breaking.length} breaking change(s) and ${ctx.faults.length} client fault(s).\n\nBefore shipping:\n${list(ctx.risk.recommendations, 4)}`;
  }
  if (/file|break|affect|impact|blast/.test(q) && !/breaking change/.test(q)) {
    if (!ctx.source) return "Scan your client code in Dependency Map and I'll tell you exactly which files break.";
    if (!ctx.faults.length) return `None of the ${ctx.source.files.length} scanned files call an endpoint with a breaking change.`;
    const byFile = new Map<string, Fault[]>();
    ctx.faults.forEach((f) => byFile.set(f.reference.file, [...(byFile.get(f.reference.file) ?? []), f]));
    return `${byFile.size} file(s) are at risk:\n${list([...byFile.entries()].map(([file, fs]) => `${file} — ${fs.length} issue(s), e.g. ${fs[0]!.change.method} ${fs[0]!.change.path} (${fs[0]!.confidence})`), 8)}`;
  }
  if (/score|risk|why/.test(q)) {
    if (!ctx.risk) return "There's no risk score yet — upload both specs first.";
    return `The score is ${ctx.risk.score}/100, which is ${ctx.risk.level}. It adds four factors:\n${list(ctx.risk.factors.map((f) => `${f.label}: ${f.score}/${f.max} (${f.explanation})`))}`;
  }
  if (/fix|worst|repair|migrat|patch/.test(q)) {
    const worst = ctx.faults[0];
    if (!worst) return breaking.length ? "No client code is affected, so there's nothing to patch — but consider a deprecation window for the breaking changes." : "There's nothing to fix.";
    return `The most urgent issue is in ${worst.reference.file}:${worst.reference.line} (\`${worst.reference.symbol}\`): ${worst.message}\n\nOpen Faults & Fixes to see the before/after code and the full migration steps.`;
  }
  if (/public|exposure|external/.test(q)) {
    const pub = [...new Set(breaking.filter((c) => c.isPublic).map((c) => `${c.method} ${c.path}`))];
    return pub.length ? `These public endpoints have breaking changes:\n${list(pub)}\n\nNotify external consumers before release.` : "No public endpoints have breaking changes.";
  }
  if (/test/.test(q)) {
    return "Open Regression Tests, pick Vitest, Jest or Supertest and generate a suite. It checks status codes, required parameters and response fields for every changed endpoint, plus 404 checks for removed ones.";
  }
  if (/change|diff|breaking|what/.test(q)) {
    if (!breaking.length) return `I found ${ctx.changes.length} change(s) and none are breaking.`;
    return `${breaking.length} breaking change(s):\n${list(breaking.map((c) => `[${c.severity}] ${c.method} ${c.path} — ${c.description}`), 8)}`;
  }
  return `In ${ctx.projectName}: ${ctx.changes.length} change(s) (${breaking.length} breaking), ${ctx.faults.length} client fault(s)${ctx.risk ? `, risk ${ctx.risk.score}/100 (${ctx.risk.level})` : ""}. Ask me about the risk score, affected files, a specific endpoint like /users, or how to fix the worst issue.`;
}
