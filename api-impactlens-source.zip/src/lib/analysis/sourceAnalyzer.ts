/* eslint-disable @typescript-eslint/no-explicit-any */
import { parse } from "@babel/parser";
import type { ApiReference, SourceAnalysis, SourceFile, SymbolKind, SymbolUsage } from "./types";

const SUPPORTED = /\.(ts|tsx|js|jsx|mjs|cjs)$/i;
const HTTP_VERBS = new Set(["get", "post", "put", "delete", "patch", "head"]);
const SKIP_KEYS = new Set(["loc", "start", "end", "extra", "comments", "leadingComments", "trailingComments", "innerComments", "range", "tokens"]);
const IGNORED_DIRS = /(^|\/)(node_modules|dist|build|\.git|\.next|coverage)\//;

/** Rejects absolute paths, traversal, null bytes and vendored folders. */
export function checkPath(path: string): { ok: true } | { ok: false; reason: string } {
  if (!path || path.includes("\0")) return { ok: false, reason: "Invalid file name" };
  const p = path.replace(/\\/g, "/");
  if (p.startsWith("/") || /^[a-zA-Z]:\//.test(p)) return { ok: false, reason: "Absolute paths are not allowed" };
  if (p.split("/").some((seg) => seg === "..")) return { ok: false, reason: "Path traversal is not allowed" };
  if (IGNORED_DIRS.test(`${p}`)) return { ok: false, reason: "Dependency or build folder" };
  if (!SUPPORTED.test(p)) return { ok: false, reason: "Unsupported file type" };
  if (/\.d\.ts$/i.test(p)) return { ok: false, reason: "Type declaration file" };
  return { ok: true };
}

const PARAM = "{param}";

/** Turns a raw client URL into a comparable route ("/users/{param}"). */
export function normalizeClientUrl(raw: string): { path: string; query: string[] } {
  let url = raw.trim();
  url = url.replace(/^https?:\/\/[^/]+/i, "");
  const qIndex = url.indexOf("?");
  const query: string[] = [];
  if (qIndex >= 0) {
    for (const part of url.slice(qIndex + 1).split("&")) {
      const name = part.split("=")[0];
      if (name && name !== PARAM) query.push(name);
    }
    url = url.slice(0, qIndex);
  }
  // Strip a leading dynamic base like `${API_BASE}/users`
  while (url.startsWith(PARAM)) url = url.slice(PARAM.length);
  if (!url.startsWith("/")) url = `/${url}`;
  url = url.replace(/\/+/g, "/").replace(/\/$/, "") || "/";
  return { path: url, query };
}

interface Sym {
  name: string;
  key: string;
  hasJsx: boolean;
  fields: Set<string>;
}

function kindOf(sym: Sym | undefined): SymbolKind {
  if (!sym) return "module";
  if (/^use[A-Z]/.test(sym.name)) return "hook";
  if (/^[A-Z]/.test(sym.name) && sym.hasJsx) return "component";
  return "function";
}

function pluginsFor(path: string): any[] {
  if (/\.tsx$/i.test(path)) return ["typescript", "jsx"];
  if (/\.(ts|mts|cts)$/i.test(path)) return ["typescript"];
  return ["jsx"];
}

function propName(node: any): string | undefined {
  if (!node) return undefined;
  if (node.type === "Identifier") return node.name;
  if (node.type === "StringLiteral") return node.value;
  return undefined;
}

export function analyzeSource(input: SourceFile[]): SourceAnalysis {
  const result: SourceAnalysis = { files: [], references: [], usages: [], skipped: [], errors: [] };
  const rawUsages: (Omit<SymbolUsage, "callerKind" | "callerFields"> & { callerSym?: Sym })[] = [];
  let refCounter = 0;

  for (const file of input) {
    const check = checkPath(file.path);
    if (!check.ok) {
      result.skipped.push({ path: file.path, reason: check.reason });
      continue;
    }
    let ast: any;
    try {
      ast = parse(file.content, { sourceType: "unambiguous", plugins: pluginsFor(file.path), errorRecovery: true } as any);
    } catch (e) {
      result.errors.push({ path: file.path, message: (e as Error).message });
      continue;
    }
    const lines = file.content.split("\n");
    const constants = new Map<string, string>();
    const fileRefs: (ApiReference & { sym?: Sym })[] = [];

    // Pass 1: string constants (const BASE_URL = "...")
    const collectConstants = (node: any) => {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) return node.forEach(collectConstants);
      if (node.type === "VariableDeclarator" && node.id?.type === "Identifier" && node.init) {
        const v = staticString(node.init, constants);
        if (v !== undefined) constants.set(node.id.name, v);
      }
      for (const k of Object.keys(node)) if (!SKIP_KEYS.has(k)) collectConstants(node[k]);
    };
    collectConstants(ast.program);

    const stack: Sym[] = [];
    const nameFromParent = (parent: any): string | undefined => {
      if (!parent) return undefined;
      if (parent.type === "VariableDeclarator" && parent.id?.type === "Identifier") return parent.id.name;
      if ((parent.type === "ObjectProperty" || parent.type === "ClassProperty") && !parent.computed) return propName(parent.key);
      if (parent.type === "AssignmentExpression" && parent.left?.type === "MemberExpression") return propName(parent.left.property);
      return undefined;
    };

    const visit = (node: any, parent: any) => {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) {
        for (const n of node) visit(n, parent);
        return;
      }
      if (typeof node.type !== "string") return;

      let pushed = false;
      let name: string | undefined;
      if (node.type === "FunctionDeclaration") name = node.id?.name;
      else if (node.type === "ArrowFunctionExpression" || node.type === "FunctionExpression") name = node.id?.name ?? nameFromParent(parent);
      else if (node.type === "ClassMethod" || node.type === "ObjectMethod") name = propName(node.key);
      // Wrapped components: const X = memo(() => ...) / forwardRef(...)
      if (!name && (node.type === "ArrowFunctionExpression" || node.type === "FunctionExpression") && parent?.type === "CallExpression") {
        name = undefined;
      }
      if (name) {
        stack.push({ name, key: `${file.path}#${name}`, hasJsx: false, fields: new Set() });
        pushed = true;
      }

      if (node.type === "JSXElement" || node.type === "JSXFragment") stack.forEach((s) => (s.hasJsx = true));
      if ((node.type === "MemberExpression" || node.type === "OptionalMemberExpression") && !node.computed) {
        const f = propName(node.property);
        if (f) stack.forEach((s) => s.fields.add(f));
      }
      if (node.type === "ObjectPattern") {
        for (const p of node.properties ?? []) {
          const f = propName(p.key);
          if (f) stack.forEach((s) => s.fields.add(f));
        }
      }

      // Function passed by reference: onClick={handler} or .then(handler)
      const refs: any[] = [];
      if (node.type === "JSXExpressionContainer" && node.expression?.type === "Identifier") refs.push(node.expression);
      if (node.type === "CallExpression") for (const a of node.arguments ?? []) if (a?.type === "Identifier") refs.push(a);
      const owner = stack[stack.length - 1];
      if (owner) for (const r of refs) if (r.name !== owner.name) rawUsages.push({ file: file.path, line: r.loc?.start.line ?? 1, caller: owner.name, callee: r.name, callerSym: owner });

      if (node.type === "CallExpression" || node.type === "OptionalCallExpression") {
        const ref = detectApiCall(node, constants);
        const current = stack[stack.length - 1];
        if (ref) {
          const line = node.loc?.start.line ?? 1;
          fileRefs.push({
            id: `ref-${++refCounter}`,
            file: file.path,
            line,
            column: (node.loc?.start.column ?? 0) + 1,
            method: ref.method,
            rawUrl: ref.rawUrl,
            path: ref.path,
            symbol: current?.name ?? "(module)",
            symbolKind: "module",
            callType: ref.callType,
            fieldsUsed: [],
            queryParams: ref.query,
            headers: ref.headers,
            snippet: (lines[line - 1] ?? "").trim(),
            ...(current ? { sym: current } : {}),
          });
        } else {
          const callee = node.callee;
          const calleeName = callee?.type === "Identifier" ? callee.name : callee?.type === "MemberExpression" && !callee.computed ? propName(callee.property) : undefined;
          if (calleeName && current && calleeName !== current.name) {
            rawUsages.push({ file: file.path, line: node.loc?.start.line ?? 1, caller: current.name, callee: calleeName, callerSym: current });
          }
        }
      }

      for (const key of Object.keys(node)) {
        if (SKIP_KEYS.has(key)) continue;
        const child = node[key];
        if (child && typeof child === "object") visit(child, node);
      }
      if (pushed) stack.pop();
    };
    visit(ast.program, null);

    for (const r of fileRefs) {
      const { sym, ...rest } = r;
      result.references.push({ ...rest, symbolKind: kindOf(sym), fieldsUsed: sym ? [...sym.fields].sort() : [] });
    }
    result.files.push({ path: file.path, lines: lines.length, references: fileRefs.length });
  }

  const apiSymbols = new Set(result.references.map((r) => r.symbol));
  const seen = new Set<string>();
  for (const u of rawUsages) {
    if (!apiSymbols.has(u.callee)) continue;
    const key = `${u.file}|${u.caller}|${u.callee}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.usages.push({ file: u.file, line: u.line, caller: u.caller, callee: u.callee, callerKind: kindOf(u.callerSym), callerFields: u.callerSym ? [...u.callerSym.fields].sort() : [] });
  }
  return result;
}

function staticString(node: any, constants: Map<string, string>): string | undefined {
  if (!node) return undefined;
  if (node.type === "StringLiteral") return node.value;
  if (node.type === "TemplateLiteral" && node.expressions.length === 0) return node.quasis.map((q: any) => q.value.cooked ?? q.value.raw).join("");
  if (node.type === "Identifier" && constants.has(node.name)) return constants.get(node.name);
  if (node.type === "TSAsExpression" || node.type === "TSSatisfiesExpression") return staticString(node.expression, constants);
  return undefined;
}

/** Best-effort URL reconstruction; dynamic parts become {param}. */
function urlOf(node: any, constants: Map<string, string>): string | undefined {
  if (!node) return undefined;
  const s = staticString(node, constants);
  if (s !== undefined) return s;
  if (node.type === "TemplateLiteral") {
    let out = "";
    node.quasis.forEach((q: any, i: number) => {
      out += q.value.cooked ?? q.value.raw;
      if (i < node.expressions.length) out += staticString(node.expressions[i], constants) ?? PARAM;
    });
    return out;
  }
  if (node.type === "BinaryExpression" && node.operator === "+") {
    const l = urlOf(node.left, constants) ?? PARAM;
    const r = urlOf(node.right, constants) ?? PARAM;
    return l + r;
  }
  return undefined;
}

function objectKeys(node: any): string[] {
  if (node?.type !== "ObjectExpression") return [];
  return node.properties.map((p: any) => propName(p.key)).filter(Boolean) as string[];
}

function objectProp(node: any, key: string): any {
  if (node?.type !== "ObjectExpression") return undefined;
  return node.properties.find((p: any) => propName(p.key) === key)?.value;
}

function looksLikeUrl(u: string): boolean {
  return u.startsWith("/") || /^https?:\/\//i.test(u) || u.startsWith(PARAM + "/") || (/^[a-z0-9_-]+\//i.test(u) && !u.includes(" "));
}

function detectApiCall(node: any, constants: Map<string, string>) {
  const callee = node.callee;
  const args = node.arguments ?? [];
  const isFetch = (callee?.type === "Identifier" && callee.name === "fetch") || (callee?.type === "MemberExpression" && propName(callee.property) === "fetch" && ["window", "globalThis", "self"].includes(callee.object?.name));
  if (isFetch) {
    const raw = urlOf(args[0], constants);
    if (!raw || !looksLikeUrl(raw)) return undefined;
    const opts = args[1];
    const methodNode = objectProp(opts, "method");
    const method = (staticString(methodNode, constants) ?? "GET").toUpperCase();
    const { path, query } = normalizeClientUrl(raw);
    return { method, rawUrl: raw, path, query, headers: objectKeys(objectProp(opts, "headers")), callType: "fetch" as const };
  }
  // axios({ url, method }) / axios.request({ ... })
  const isAxiosConfig = (callee?.type === "Identifier" && callee.name === "axios") || (callee?.type === "MemberExpression" && propName(callee.property) === "request");
  if (isAxiosConfig && args[0]?.type === "ObjectExpression") {
    const raw = urlOf(objectProp(args[0], "url"), constants);
    if (!raw || !looksLikeUrl(raw)) return undefined;
    const method = (staticString(objectProp(args[0], "method"), constants) ?? "GET").toUpperCase();
    const { path, query } = normalizeClientUrl(raw);
    return { method, rawUrl: raw, path, query: [...query, ...objectKeys(objectProp(args[0], "params"))], headers: objectKeys(objectProp(args[0], "headers")), callType: "axios" as const };
  }
  if (callee?.type === "MemberExpression" && !callee.computed) {
    const verb = propName(callee.property)?.toLowerCase();
    if (!verb || !HTTP_VERBS.has(verb)) return undefined;
    const raw = urlOf(args[0], constants);
    if (!raw || !looksLikeUrl(raw)) return undefined;
    const config = verb === "get" || verb === "delete" || verb === "head" ? args[1] : args[2];
    const { path, query } = normalizeClientUrl(raw);
    const objName = callee.object?.type === "Identifier" ? callee.object.name : "";
    return {
      method: verb.toUpperCase(),
      rawUrl: raw,
      path,
      query: [...query, ...objectKeys(objectProp(config, "params"))],
      headers: objectKeys(objectProp(config, "headers")),
      callType: objName === "axios" ? ("axios" as const) : ("client" as const),
    };
  }
  return undefined;
}
