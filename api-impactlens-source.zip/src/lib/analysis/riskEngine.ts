import type { ApiChange, Fault, RiskAssessment, RiskLevel, Severity, SourceAnalysis } from "./types";

export const SEVERITY_WEIGHTS: Record<Severity, number> = { critical: 10, high: 6, medium: 3, low: 1 };
export const RISK_FORMULA =
  "Risk = Breaking (0–40) + Severity (0–25) + Blast radius (0–25) + Public exposure (0–10), capped at 100";

const clamp = (v: number, max: number) => Math.max(0, Math.min(max, Math.round(v)));

export function levelFor(score: number): RiskLevel {
  if (score >= 75) return "Critical";
  if (score >= 50) return "High";
  if (score >= 25) return "Medium";
  return "Low";
}

export function computeRisk(changes: ApiChange[], faults: Fault[], source?: Pick<SourceAnalysis, "references"> | null): RiskAssessment {
  const breaking = changes.filter((c) => c.breaking);
  const affectedChangeIds = new Set(faults.map((f) => f.change.id));
  const affectedBreaking = breaking.filter((c) => affectedChangeIds.has(c.id)).length;

  const severityCounts: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 };
  breaking.forEach((c) => severityCounts[c.severity]++);

  const breakingRaw = breaking.length * 6 + affectedBreaking * 4;
  const severityRaw = breaking.reduce((s, c) => s + SEVERITY_WEIGHTS[c.severity], 0);

  const files = new Set(faults.map((f) => f.reference.file));
  const symbols = new Set(faults.flatMap((f) => [`${f.reference.file}#${f.reference.symbol}`, ...f.impactedCallers.map((u) => `${u.file}#${u.caller}`)]));
  const endpoints = new Set(faults.map((f) => `${f.change.method} ${f.change.path}`));
  const blastRaw = files.size * 4 + symbols.size * 2 + endpoints.size * 3;

  const publicEndpoints = new Set(breaking.filter((c) => c.isPublic).map((c) => `${c.method} ${c.path}`));
  const exposureRaw = publicEndpoints.size * 4;

  const factors: RiskAssessment["factors"] = [
    { key: "breaking", label: "Breaking changes", score: clamp(breakingRaw, 40), max: 40, explanation: `${breaking.length} breaking × 6 + ${affectedBreaking} hitting client code × 4 = ${breakingRaw}` },
    { key: "severity", label: "Severity weight", score: clamp(severityRaw, 25), max: 25, explanation: `critical ${severityCounts.critical}×10 + high ${severityCounts.high}×6 + medium ${severityCounts.medium}×3 + low ${severityCounts.low}×1 = ${severityRaw}` },
    { key: "blast", label: "Blast radius", score: clamp(blastRaw, 25), max: 25, explanation: `${files.size} files × 4 + ${symbols.size} symbols × 2 + ${endpoints.size} endpoints × 3 = ${blastRaw}` },
    { key: "exposure", label: "Public exposure", score: clamp(exposureRaw, 10), max: 10, explanation: `${publicEndpoints.size} public endpoints with breaking changes × 4 = ${exposureRaw}` },
  ];
  const score = clamp(factors.reduce((s, f) => s + f.score, 0), 100);

  const byEndpoint = new Map<string, RiskAssessment["highRiskEndpoints"][number]>();
  const sevRank: Severity[] = ["critical", "high", "medium", "low"];
  for (const c of breaking) {
    const key = `${c.method} ${c.path}`;
    const e = byEndpoint.get(key) ?? { method: c.method, path: c.path, score: 0, changes: 0, faults: 0, topSeverity: "low" as Severity };
    e.changes++;
    e.score += SEVERITY_WEIGHTS[c.severity];
    if (sevRank.indexOf(c.severity) < sevRank.indexOf(e.topSeverity)) e.topSeverity = c.severity;
    byEndpoint.set(key, e);
  }
  for (const f of faults) {
    const e = byEndpoint.get(`${f.change.method} ${f.change.path}`);
    if (e) {
      e.faults++;
      e.score += f.confidence === "confirmed" ? 5 : 2;
    }
  }
  const highRiskEndpoints = [...byEndpoint.values()].sort((a, b) => b.score - a.score).slice(0, 6);

  const recommendations: string[] = [];
  const has = (t: ApiChange["type"]) => breaking.some((c) => c.type === t);
  if (has("endpoint-removed") || has("method-removed")) recommendations.push("Keep removed endpoints alive behind a deprecation window (e.g. 90 days) and return a `Sunset` header before deleting them.");
  if (has("response-field-removed")) recommendations.push("Serve removed or renamed response fields alongside their replacements for one release so clients can migrate.");
  if (has("param-required-added") || has("param-made-required")) recommendations.push("Give new required parameters a server-side default for existing clients, or version the endpoint.");
  if (has("response-field-type-changed") || has("param-type-changed")) recommendations.push("Avoid changing field types in place — add a new field (e.g. `amountDecimal`) and deprecate the old one.");
  if (has("enum-value-removed")) recommendations.push("Keep accepting removed enum values and map them to their replacements on the server.");
  if (has("request-field-required-added") || has("request-body-required")) recommendations.push("Make new request body fields optional with sensible defaults until clients are updated.");
  if (publicEndpoints.size) recommendations.push(`${publicEndpoints.size} public endpoint(s) change — announce the release to external consumers and publish a migration guide.`);
  if (faults.length) recommendations.push(`Patch the ${files.size} affected client file(s) using the generated fixes before deploying the new API.`);
  if (!source?.references?.length) recommendations.push("Scan the consuming client code to measure the real blast radius.");
  if (!breaking.length) recommendations.push("No breaking changes found — this release looks backwards compatible.");
  recommendations.push("Run the generated regression suite against staging before releasing.");

  return {
    score,
    level: levelFor(score),
    factors,
    formula: RISK_FORMULA,
    blastRadius: { files: files.size, symbols: symbols.size, endpoints: endpoints.size, references: faults.length },
    highRiskEndpoints,
    recommendations,
    severityCounts,
  };
}
