import type { ApiChange, ApiReference, Fault, SymbolUsage } from "./types";

const segs = (p: string) => p.replace(/\?.*$/, "").split("/").filter(Boolean);
const isParam = (s: string) => /^\{[^}]*\}$/.test(s) || s.startsWith(":");

/**
 * True when a client route (e.g. "/v1/users/{param}") targets a spec route ("/users/{id}").
 * Client paths may carry a base prefix, so the spec route is matched against the client's tail.
 */
export function matchRoute(clientPath: string, specPath: string): boolean {
  const c = segs(clientPath);
  const s = segs(specPath);
  if (s.length === 0) return c.length === 0;
  if (c.length < s.length) return false;
  const tail = c.slice(c.length - s.length);
  return s.every((spec, i) => {
    const client = tail[i]!;
    if (isParam(spec)) return true;
    if (isParam(client)) return false;
    return spec.toLowerCase() === client.toLowerCase();
  });
}

/** Picks the most specific spec path for a client path, so "/users/{param}" doesn't also hit "/users". */
export function bestSpecMatch(clientPath: string, specPaths: string[]): string | undefined {
  const candidates = specPaths.filter((p) => matchRoute(clientPath, p));
  if (!candidates.length) return undefined;
  const score = (p: string) => segs(p).length * 10 + segs(p).filter((s) => !isParam(s)).length;
  return candidates.sort((a, b) => score(b) - score(a))[0];
}

function similarity(a: string, b: string) {
  const sa = new Set(segs(a).filter((s) => !isParam(s)));
  const sb = new Set(segs(b).filter((s) => !isParam(s)));
  let common = 0;
  sa.forEach((s) => sb.has(s) && common++);
  return common / Math.max(1, Math.max(sa.size, sb.size));
}

function suggestReplacement(change: ApiChange, changes: ApiChange[]): string | undefined {
  const added = changes.filter((c) => c.type === "endpoint-added" || c.type === "method-added");
  let best: { c: ApiChange; s: number } | undefined;
  for (const c of added) {
    const s = similarity(change.path, c.path) + (c.method === change.method ? 0.25 : 0);
    if (s > 0.25 && (!best || s > best.s)) best = { c, s };
  }
  return best ? `${best.c.method} ${best.c.path}` : undefined;
}

export function detectFaults(changes: ApiChange[], references: ApiReference[], usages: SymbolUsage[], specPaths?: string[]): Fault[] {
  const faults: Fault[] = [];
  const allPaths = specPaths ?? [...new Set(changes.map((c) => c.path))];
  let n = 0;
  for (const change of changes) {
    if (!change.breaking) continue;
    for (const ref of references) {
      if (ref.method !== change.method) continue;
      const pool = allPaths.includes(change.path) ? allPaths : [...allPaths, change.path];
      if (bestSpecMatch(ref.path, pool) !== change.path) continue;
      const callers = usages.filter((u) => u.callee === ref.symbol);
      const fields = new Set([...ref.fieldsUsed, ...callers.flatMap((u) => u.callerFields)]);
      let confidence: Fault["confidence"] = "possible";
      let message = "";
      switch (change.type) {
        case "endpoint-removed":
        case "method-removed":
          confidence = "confirmed";
          message = `\`${ref.symbol}\` calls ${change.method} ${change.path}, which no longer exists — this request will fail with 404/405.`;
          break;
        case "response-field-removed":
        case "response-field-type-changed":
          if (change.field && fields.has(change.field)) {
            confidence = "confirmed";
            message = change.type === "response-field-removed"
              ? `\`${ref.symbol}\`${callers.length ? " and its callers" : ""} read \`${change.field}\`, which is no longer returned${change.renamedTo ? ` (now \`${change.renamedTo}\`)` : ""}.`
              : `\`${change.field}\` is read by \`${ref.symbol}\` but changed from ${change.before} to ${change.after}.`;
          } else {
            message = `${change.description} \`${ref.symbol}\` consumes this response; check whether it depends on \`${change.field}\`.`;
          }
          break;
        case "param-required-added":
        case "param-made-required":
          if (change.paramIn === "query" && change.field && ref.queryParams.includes(change.field)) continue;
          if (change.paramIn === "header" && change.field && ref.headers.some((h) => h.toLowerCase() === change.field!.toLowerCase())) continue;
          confidence = change.paramIn === "query" || change.paramIn === "header" ? "confirmed" : "possible";
          message = `\`${ref.symbol}\` does not send the now-required ${change.paramIn} parameter \`${change.field}\` — expect 400 responses.`;
          break;
        case "enum-value-removed":
          message = `${change.description} Verify \`${ref.symbol}\` never sends a removed value.`;
          break;
        default:
          message = `${change.description} Affects \`${ref.symbol}\`.`;
      }
      const fault: Fault = { id: `flt-${++n}`, change, reference: ref, confidence, message, impactedCallers: callers };
      if (change.type === "endpoint-removed" || change.type === "method-removed") {
        const r = suggestReplacement(change, changes);
        if (r) fault.replacement = r;
      }
      faults.push(fault);
    }
  }
  const rank = { confirmed: 0, possible: 1 } as const;
  const sev = { critical: 0, high: 1, medium: 2, low: 3 } as const;
  return faults.sort((a, b) => rank[a.confidence] - rank[b.confidence] || sev[a.change.severity] - sev[b.change.severity]);
}
