import type { CodeFix, Fault } from "./types";

/** Minimal line-based unified diff (LCS). */
export function unifiedDiff(before: string, after: string, file = "file", startLine = 1): string {
  const a = before.split("\n");
  const b = after.split("\n");
  const dp: number[][] = Array.from({ length: a.length + 1 }, () => new Array<number>(b.length + 1).fill(0));
  for (let i = a.length - 1; i >= 0; i--)
    for (let j = b.length - 1; j >= 0; j--)
      dp[i]![j] = a[i] === b[j] ? dp[i + 1]![j + 1]! + 1 : Math.max(dp[i + 1]![j]!, dp[i]![j + 1]!);
  const lines: string[] = [];
  let i = 0, j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) { lines.push(` ${a[i]}`); i++; j++; }
    else if (dp[i + 1]![j]! >= dp[i]![j + 1]!) { lines.push(`-${a[i]}`); i++; }
    else { lines.push(`+${b[j]}`); j++; }
  }
  while (i < a.length) lines.push(`-${a[i++]}`);
  while (j < b.length) lines.push(`+${b[j++]}`);
  return [`--- a/${file}`, `+++ b/${file}`, `@@ -${startLine},${a.length} +${startLine},${b.length} @@`, ...lines].join("\n");
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function indentOf(line: string) {
  return line.match(/^\s*/)?.[0] ?? "";
}

/** Adds `name=${name}` to the URL literal on a line, converting it to a template literal if needed. */
function addQueryParam(line: string, name: string): string {
  const re = /(["'`])((?:\\.|(?!\1).)*?)\1/;
  const m = line.match(re);
  if (!m || m.index === undefined) return line;
  const [full, , content] = m;
  if (!content?.includes("/")) return line;
  const sep = content.includes("?") ? "&" : "?";
  const replaced = "`" + content.replace(/`/g, "\\`") + `${sep}${name}=\${encodeURIComponent(${toIdent(name)})}` + "`";
  return line.slice(0, m.index) + replaced + line.slice(m.index + full.length);
}

function toIdent(name: string) {
  const id = name.replace(/[^a-zA-Z0-9]+(.)?/g, (_, c: string | undefined) => (c ? c.toUpperCase() : "")).replace(/^[0-9]/, "_$&");
  return id.charAt(0).toLowerCase() + id.slice(1);
}

export function generateFix(fault: Fault, fileContent: string): CodeFix {
  const { change, reference: ref } = fault;
  const all = fileContent.split("\n");
  const start = Math.max(1, ref.line - 2);
  const end = Math.min(all.length, ref.line + 6);
  const window = all.slice(start - 1, end);
  const callIdx = ref.line - start;
  const after = [...window];
  const indent = indentOf(window[callIdx] ?? "");
  const steps: string[] = [];
  let title = "";

  switch (change.type) {
    case "response-field-removed": {
      const field = change.field ?? "";
      const re = new RegExp(`(\\?)?\\.${escapeRe(field)}\\b`, "g");
      let touched = false;
      for (let i = 0; i < after.length; i++) {
        if (re.test(after[i]!)) {
          touched = true;
          after[i] = change.renamedTo
            ? after[i]!.replace(re, (_m, opt?: string) => `${opt ?? ""}.${change.renamedTo}`)
            : after[i]!.replace(re, (_m, _opt?: string) => `?.${field}`);
        }
        re.lastIndex = 0;
      }
      const note = change.renamedTo
        ? `// ImpactLens: '${field}' was renamed to '${change.renamedTo}' in the new API version.`
        : `// ImpactLens: '${field}' is no longer returned — guard against undefined and provide a fallback.`;
      after.splice(touched ? 0 : callIdx, 0, `${indentOf(window[0] ?? "")}${note}`);
      title = change.renamedTo ? `Rename \`${field}\` → \`${change.renamedTo}\`` : `Guard removed field \`${field}\``;
      steps.push(
        change.renamedTo ? `Replace every read of \`${field}\` with \`${change.renamedTo}\` in ${ref.file} and in components that consume \`${ref.symbol}\`.` : `Remove the dependency on \`${field}\` or read it optionally (\`?.${field}\`) with a fallback value.`,
        "Update the TypeScript response type so the compiler flags remaining usages.",
        ...fault.impactedCallers.map((u) => `Check \`${u.caller}\` in ${u.file}:${u.line}, which renders data from \`${ref.symbol}\`.`),
        "Run the regression suite to confirm the response shape.",
      );
      break;
    }
    case "response-field-type-changed": {
      const field = change.field ?? "";
      after.splice(callIdx, 0, `${indent}// ImpactLens: '${field}' changed from ${change.before} to ${change.after}. Normalise it before use, e.g. Number(item.${field}).`);
      title = `Normalise \`${field}\` (${change.before} → ${change.after})`;
      steps.push(`Coerce \`${field}\` to the type your code expects at the API boundary (inside \`${ref.symbol}\`).`, "Update the response type definition.", "Add a test asserting the parsed value type.");
      break;
    }
    case "param-required-added":
    case "param-made-required": {
      const name = change.field ?? "param";
      if (change.paramIn === "query") {
        after[callIdx] = addQueryParam(after[callIdx] ?? "", name);
        after.splice(callIdx, 0, `${indent}// ImpactLens: '${name}' is now a required query parameter.`);
        steps.push(`Pass a \`${toIdent(name)}\` value into \`${ref.symbol}\` (add it as a function argument with a sensible default).`);
      } else if (change.paramIn === "header") {
        after.splice(callIdx, 0, `${indent}// ImpactLens: add the required '${name}' header, e.g. headers: { "${name}": ${toIdent(name)} }`);
        steps.push(`Send the \`${name}\` header on this request — ideally from a shared HTTP client interceptor so every call gets it.`);
      } else {
        after.splice(callIdx, 0, `${indent}// ImpactLens: '${name}' (${change.paramIn}) is now required.`);
        steps.push(`Provide \`${name}\` on every call to ${change.method} ${change.path}.`);
      }
      title = `Send required ${change.paramIn} parameter \`${name}\``;
      steps.push("Update callers to supply the new value.", "Re-run the regression tests for this endpoint.");
      break;
    }
    case "endpoint-removed":
    case "method-removed": {
      const target = fault.replacement;
      if (target) {
        const [, newPath] = target.split(" ");
        const oldTail = change.path.split("/").filter((s) => s && !s.startsWith("{")).join("/");
        const newTail = (newPath ?? "").split("/").filter((s) => s && !s.startsWith("{")).join("/");
        if (oldTail && newTail && after[callIdx]?.includes(oldTail)) after[callIdx] = after[callIdx]!.replace(oldTail, newTail);
        after.splice(callIdx, 0, `${indent}// ImpactLens: ${change.method} ${change.path} was removed — migrated to ${target}.`);
        title = `Migrate to ${target}`;
        steps.push(`Point \`${ref.symbol}\` at ${target} and confirm its response shape matches.`);
      } else {
        after.splice(callIdx, 0, `${indent}// ImpactLens: ${change.method} ${change.path} no longer exists. Remove this call or ask the API team for a replacement.`);
        title = `Remove call to ${change.method} ${change.path}`;
        steps.push(`Remove or feature-flag \`${ref.symbol}\` — the endpoint no longer exists.`);
      }
      steps.push(...fault.impactedCallers.map((u) => `Update \`${u.caller}\` (${u.file}:${u.line}), which calls \`${ref.symbol}\`.`), "Ask the API team to keep the old endpoint behind a deprecation window until all clients ship.");
      break;
    }
    case "enum-value-removed": {
      after.splice(callIdx, 0, `${indent}// ImpactLens: allowed values for '${change.field}' are now ${change.after}.`);
      title = `Restrict \`${change.field}\` to supported values`;
      steps.push(`Update the union type for \`${change.field}\` to ${change.after}.`, "Map removed values to their replacements before calling the API.");
      break;
    }
    default: {
      after.splice(callIdx, 0, `${indent}// ImpactLens: ${change.description}`);
      title = change.description;
      steps.push(`Review ${ref.file}:${ref.line} against the new contract.`, "Update the request payload/types and re-run tests.");
    }
  }

  const before = window.join("\n");
  const afterText = after.join("\n");
  return { title, file: ref.file, startLine: start, before, after: afterText, diff: unifiedDiff(before, afterText, ref.file, start), steps };
}
