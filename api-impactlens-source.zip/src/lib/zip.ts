import type { SourceFile } from "./analysis/types";
import { checkPath } from "./analysis/sourceAnalyzer";

const MAX_FILES = 1500;
const MAX_FILE_BYTES = 400_000;

export async function readZip(file: File | Blob): Promise<{ files: SourceFile[]; skipped: number }> {
  const { default: JSZip } = await import("jszip");
  const zip = await JSZip.loadAsync(file);
  const entries = Object.values(zip.files).filter((e) => !e.dir);
  // Drop a single shared top folder ("my-app/src/x.ts" -> "src/x.ts")
  const first = entries[0]?.name.split("/")[0];
  const shared = first && entries.every((e) => e.name.startsWith(`${first}/`)) ? `${first}/` : "";
  const files: SourceFile[] = [];
  let skipped = 0;
  for (const e of entries) {
    const path = e.name.slice(shared.length);
    if (!checkPath(path).ok || files.length >= MAX_FILES) {
      skipped++;
      continue;
    }
    const content = await e.async("string");
    if (content.length > MAX_FILE_BYTES) {
      skipped++;
      continue;
    }
    files.push({ path, content });
  }
  return { files, skipped };
}

export async function readFolder(list: FileList): Promise<{ files: SourceFile[]; skipped: number; label: string }> {
  const files: SourceFile[] = [];
  let skipped = 0;
  const all = Array.from(list);
  const root = (all[0]?.webkitRelativePath ?? "").split("/")[0] ?? "folder";
  for (const f of all) {
    const rel = (f.webkitRelativePath || f.name).split("/").slice(1).join("/") || f.name;
    if (!checkPath(rel).ok || f.size > MAX_FILE_BYTES || files.length >= MAX_FILES) {
      skipped++;
      continue;
    }
    files.push({ path: rel, content: await f.text() });
  }
  return { files, skipped, label: root };
}

export async function buildZip(files: SourceFile[], folder: string): Promise<Blob> {
  const { default: JSZip } = await import("jszip");
  const zip = new JSZip();
  for (const f of files) zip.file(`${folder}/${f.path}`, f.content);
  return zip.generateAsync({ type: "blob" });
}
