import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { makeSampleProject } from "./sample-project";
import { newId as uid, WorkspaceContext, type Project, type WorkspaceValue } from "./workspace-context";

const STORAGE_KEY = "impactlens.workspace.v1";

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeId, setActiveIdState] = useState<string | null>(null);
  const warned = useRef(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { projects: Project[]; activeId: string | null };
        if (parsed.projects?.length) {
          setProjects(parsed.projects);
          setActiveIdState(parsed.activeId ?? parsed.projects[0]!.id);
          setReady(true);
          return;
        }
      }
    } catch {
      /* fall through to seeding */
    }
    const sample = makeSampleProject();
    setProjects([sample]);
    setActiveIdState(sample.id);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ projects, activeId }));
    } catch {
      if (!warned.current) {
        warned.current = true;
        toast.error("Browser storage is full", { description: "Your latest changes work now but may not survive a reload. Try uploading a smaller code archive." });
      }
    }
  }, [projects, activeId, ready]);

  const createProject = useCallback((name: string) => {
    const p: Project = { id: uid(), name: name.trim() || "Untitled project", createdAt: new Date().toISOString(), oldSpec: null, newSpec: null, source: null, chat: [] };
    setProjects((prev) => [...prev, p]);
    setActiveIdState(p.id);
    return p;
  }, []);

  const createSampleProject = useCallback(() => {
    const p = makeSampleProject();
    setProjects((prev) => [...prev, p]);
    setActiveIdState(p.id);
    return p;
  }, []);

  const deleteProject = useCallback((id: string) => {
    setProjects((prev) => {
      const next = prev.filter((p) => p.id !== id);
      setActiveIdState((cur) => (cur === id ? (next[0]?.id ?? null) : cur));
      return next;
    });
  }, []);

  const updateActive = useCallback(
    (patch: Partial<Omit<Project, "id">>) => {
      setProjects((prev) => prev.map((p) => (p.id === activeId ? { ...p, ...patch } : p)));
    },
    [activeId],
  );

  const active = projects.find((p) => p.id === activeId) ?? null;
  const value = useMemo<WorkspaceValue>(
    () => ({ ready, projects, active, setActiveId: setActiveIdState, createProject, createSampleProject, deleteProject, updateActive }),
    [ready, projects, active, createProject, createSampleProject, deleteProject, updateActive],
  );
  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}
