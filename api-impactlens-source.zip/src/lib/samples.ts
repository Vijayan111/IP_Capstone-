import apiV1 from "../../samples/api-v1.yaml?raw";
import apiV2 from "../../samples/api-v2.yaml?raw";
import type { SourceFile } from "./analysis/types";

const clientModules = import.meta.glob("../../samples/sample-client-app/**/*.{ts,tsx,json}", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

export const SAMPLE_V1 = apiV1;
export const SAMPLE_V2 = apiV2;

export const SAMPLE_CLIENT_FILES: SourceFile[] = Object.entries(clientModules)
  .map(([key, content]) => ({ path: key.replace(/^.*sample-client-app\//, ""), content }))
  .sort((a, b) => a.path.localeCompare(b.path));
