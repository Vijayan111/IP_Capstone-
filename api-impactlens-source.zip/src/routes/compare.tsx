import { createFileRoute } from "@tanstack/react-router";
import { Download, FileUp, RotateCcw } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState, MethodTag, PageHeader, SeverityBadge, WorkspaceGate } from "@/components/impact/ui";
import { renderTicks } from "@/components/impact/ticks";
import { specTitle } from "@/lib/analysis/openapi";
import type { ApiChange, Severity } from "@/lib/analysis/types";
import { downloadText } from "@/lib/download";
import { SAMPLE_V1, SAMPLE_V2 } from "@/lib/samples";
import { pageHead } from "@/lib/seo";
import { useWorkspace, type SpecInput } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/compare")({
  head: () => pageHead("API Comparison", "Upload two OpenAPI specs and see every breaking and non-breaking change, ranked by severity."),
  component: () => (
    <WorkspaceGate>
      <ComparePage />
    </WorkspaceGate>
  ),
});

function SpecPanel({ label, value, error, title, onChange, sample, sampleName }: { label: string; value: SpecInput | null; error: string | null; title: string; onChange: (v: SpecInput | null) => void; sample: string; sampleName: string }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [draft, setDraft] = useState<string | null>(null);
  const text = draft ?? value?.text ?? "";
  return (
    <div className="panel flex flex-col p-5">
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <p className="eyebrow text-muted-foreground">{label}</p>
          <p className="mt-1 truncate font-mono text-sm">{value ? `${value.name} · ${title}` : "No spec yet"}</p>
        </div>
        <div className="flex gap-1.5">
          <input
            ref={fileRef}
            type="file"
            accept=".yaml,.yml,.json"
            className="hidden"
            aria-label={`Upload ${label}`}
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              setDraft(null);
              onChange({ name: f.name, text: await f.text() });
              e.target.value = "";
            }}
          />
          <Button variant="panel" size="sm" onClick={() => fileRef.current?.click()}>
            <FileUp /> Upload
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { setDraft(null); onChange({ name: sampleName, text: sample }); }}>
            <RotateCcw /> Sample
          </Button>
        </div>
      </div>
      <Textarea
        value={text}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          if (draft !== null) {
            onChange(draft.trim() ? { name: value?.name ?? "pasted.yaml", text: draft } : null);
            setDraft(null);
          }
        }}
        placeholder="Paste OpenAPI YAML or JSON, or upload a file…"
        spellCheck={false}
        className="h-56 resize-y bg-code font-mono text-xs"
      />
      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function ComparePage() {
  const { active, updateActive } = useWorkspace();
  const a = useAnalysis();
  const [tab, setTab] = useState<"breaking" | "safe" | "all">("breaking");
  const list = useMemo(() => (tab === "breaking" ? a.breaking : tab === "safe" ? a.changes.filter((c) => !c.breaking) : a.changes), [tab, a.changes, a.breaking]);
  const grouped = useMemo(() => {
    const m = new Map<string, ApiChange[]>();
    for (const c of list) m.set(`${c.method} ${c.path}`, [...(m.get(`${c.method} ${c.path}`) ?? []), c]);
    return [...m.entries()];
  }, [list]);
  const counts = (["critical", "high", "medium", "low"] as Severity[]).map((s) => [s, a.breaking.filter((c) => c.severity === s).length] as const);

  return (
    <>
      <PageHeader
        eyebrow="Module 1 · Semantic diff"
        title="API Comparison"
        description="Compare a previous and an updated OpenAPI 3.x spec. Edits are analysed as soon as you click away from the box."
        actions={
          <>
            <Button variant="panel" size="sm" onClick={() => downloadText("api-v1.yaml", SAMPLE_V1, "text/yaml")}>
              <Download /> api-v1.yaml
            </Button>
            <Button variant="panel" size="sm" onClick={() => downloadText("api-v2.yaml", SAMPLE_V2, "text/yaml")}>
              <Download /> api-v2.yaml
            </Button>
          </>
        }
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <SpecPanel key={`o-${active?.id}`} label="Previous spec" value={active?.oldSpec ?? null} error={a.oldError} title={specTitle(a.oldSpec)} onChange={(v) => updateActive({ oldSpec: v })} sample={SAMPLE_V1} sampleName="api-v1.yaml" />
        <SpecPanel key={`n-${active?.id}`} label="Updated spec" value={active?.newSpec ?? null} error={a.newError} title={specTitle(a.newSpec)} onChange={(v) => updateActive({ newSpec: v })} sample={SAMPLE_V2} sampleName="api-v2.yaml" />
      </div>

      <section className="mt-8">
        {!a.hasSpecs ? (
          <EmptyState title="Waiting for two valid specs" body="Upload or paste both versions above. Use “Sample” to try the Billing & User Management example." />
        ) : (
          <>
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                {counts.map(([s, n]) => (
                  <span key={s} className="flex items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-1.5 text-xs">
                    <SeverityBadge severity={s} /> <span className="font-mono">{n}</span>
                  </span>
                ))}
              </div>
              <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
                <TabsList>
                  <TabsTrigger value="breaking">Breaking ({a.breaking.length})</TabsTrigger>
                  <TabsTrigger value="safe">Non-breaking ({a.changes.length - a.breaking.length})</TabsTrigger>
                  <TabsTrigger value="all">All ({a.changes.length})</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            {grouped.length === 0 ? (
              <EmptyState title="Nothing here" body={tab === "breaking" ? "No breaking changes — this release is backwards compatible." : "No changes in this view."} />
            ) : (
              <div className="space-y-3">
                {grouped.map(([key, items]) => (
                  <div key={key} className="panel overflow-hidden">
                    <div className="flex items-center gap-3 border-b border-border bg-surface-raised px-4 py-2.5">
                      <MethodTag method={items[0]!.method} />
                      <span className="font-mono text-sm">{items[0]!.path}</span>
                      {items[0]!.isPublic && <span className="ml-auto font-mono text-[10px] uppercase tracking-wider text-info">public</span>}
                    </div>
                    <ul className="divide-y divide-border">
                      {items.map((c) => (
                        <li key={c.id} className="grid gap-2 px-4 py-3 sm:grid-cols-[90px_1fr_auto] sm:items-center">
                          <div>{c.breaking ? <SeverityBadge severity={c.severity} /> : <span className="font-mono text-[10px] uppercase tracking-wider text-sev-low">safe</span>}</div>
                          <div>
                            <p className="text-sm">{renderTicks(c.description)}</p>
                            <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">{c.location}</p>
                          </div>
                          {(c.before || c.after) && (
                            <div className="font-mono text-[11px]">
                              {c.before && <span className="text-diff-del line-through">{c.before}</span>}
                              {c.before && c.after && <span className="mx-1.5 text-muted-foreground">→</span>}
                              {c.after && <span className="text-diff-add">{c.after}</span>}
                            </div>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </>
  );
}
