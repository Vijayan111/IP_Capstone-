import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, Cell, PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { EmptyState, MethodTag, PageHeader, SeverityBadge, StatCard, WorkspaceGate } from "@/components/impact/ui";
import { RiskGauge } from "@/components/impact/RiskGauge";
import { pageHead } from "@/lib/seo";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/risk")({
  head: () => pageHead("Risk Intelligence", "A transparent 0–100 release risk score built from breaking changes, severity, blast radius and public exposure."),
  component: () => (
    <WorkspaceGate>
      <RiskPage />
    </WorkspaceGate>
  ),
});

const SEV_FILL = { critical: "var(--sev-critical)", high: "var(--sev-high)", medium: "var(--sev-medium)", low: "var(--sev-low)" } as const;

function RiskPage() {
  const a = useAnalysis();
  const risk = a.risk;
  if (!risk) return <EmptyState title="No risk score yet" body="Upload both specs in API Comparison to calculate the release risk." to="/compare" cta="Compare specs" />;

  const sevData = (Object.keys(risk.severityCounts) as (keyof typeof SEV_FILL)[]).map((k) => ({ name: k, value: risk.severityCounts[k] }));
  const radar = risk.factors.map((f) => ({ factor: f.label, pct: Math.round((f.score / f.max) * 100) }));

  return (
    <>
      <PageHeader eyebrow="Module 3 · Risk engine" title="Risk Intelligence" description={risk.formula} />
      <div className="grid gap-4 lg:grid-cols-[1fr_2fr]">
        <div className="panel flex flex-col items-center justify-center p-6">
          <RiskGauge score={risk.score} level={risk.level} size={240} />
        </div>
        <div className="panel p-6">
          <h2 className="text-lg font-semibold">Score breakdown</h2>
          <ul className="mt-4 space-y-4">
            {risk.factors.map((f) => (
              <li key={f.key}>
                <div className="flex items-baseline justify-between text-sm">
                  <span>{f.label}</span>
                  <span className="font-mono">
                    <span className="text-primary">{f.score}</span>
                    <span className="text-muted-foreground">/{f.max}</span>
                  </span>
                </div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-gradient-to-r from-primary to-sev-high transition-all duration-700" style={{ width: `${(f.score / f.max) * 100}%` }} />
                </div>
                <p className="mt-1 font-mono text-[11px] text-muted-foreground">{f.explanation}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Affected files" value={risk.blastRadius.files} />
        <StatCard label="Affected symbols" value={risk.blastRadius.symbols} />
        <StatCard label="Affected endpoints" value={risk.blastRadius.endpoints} />
        <StatCard label="Fault sites" value={risk.blastRadius.references} tone={risk.blastRadius.references ? "critical" : "low"} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="panel p-6">
          <h2 className="text-lg font-semibold">Breaking changes by severity</h2>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <BarChart data={sevData}>
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis allowDecimals={false} stroke="var(--muted-foreground)" fontSize={11} tickLine={false} axisLine={false} width={28} />
                <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--foreground)" }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {sevData.map((d) => (
                    <Cell key={d.name} fill={SEV_FILL[d.name]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="panel p-6">
          <h2 className="text-lg font-semibold">Factor saturation</h2>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <RadarChart data={radar} outerRadius="72%">
                <PolarGrid stroke="var(--border)" />
                <PolarAngleAxis dataKey="factor" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
                <Radar dataKey="pct" stroke="var(--primary)" fill="var(--primary)" fillOpacity={0.25} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="panel p-6">
          <h2 className="text-lg font-semibold">High-risk endpoints</h2>
          {risk.highRiskEndpoints.length ? (
            <ol className="mt-4 divide-y divide-border">
              {risk.highRiskEndpoints.map((e, i) => (
                <li key={`${e.method} ${e.path}`} className="flex items-center gap-3 py-2.5">
                  <span className="w-4 font-mono text-xs text-muted-foreground">{i + 1}</span>
                  <MethodTag method={e.method} />
                  <span className="flex-1 truncate font-mono text-xs">{e.path}</span>
                  <SeverityBadge severity={e.topSeverity} />
                  <span className="w-16 text-right font-mono text-xs text-muted-foreground">{e.faults} faults</span>
                </li>
              ))}
            </ol>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">No breaking endpoints.</p>
          )}
        </div>
        <div className="panel p-6">
          <h2 className="text-lg font-semibold">Recommendations</h2>
          <ol className="mt-4 space-y-3">
            {risk.recommendations.map((r, i) => (
              <li key={i} className="flex gap-3 text-sm">
                <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full border border-primary/40 font-mono text-[10px] text-primary">{i + 1}</span>
                <span>{r}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </>
  );
}
