import { createFileRoute } from "@tanstack/react-router";
import { Download, FlaskConical } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { CodeBlock, CopyButton, EmptyState, PageHeader, WorkspaceGate } from "@/components/impact/ui";
import { deploymentChecklist, generateTests, type TestFramework } from "@/lib/analysis/testGenerator";
import { downloadText } from "@/lib/download";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/tests")({
  head: () => pageHead("Regression Tests", "Generate ready-to-run Vitest, Jest or Supertest suites that check status codes, required parameters and response fields."),
  component: () => (
    <WorkspaceGate>
      <TestsPage />
    </WorkspaceGate>
  ),
});

const FRAMEWORKS: { id: TestFramework; label: string; note: string }[] = [
  { id: "vitest", label: "Vitest", note: "fetch + vitest" },
  { id: "jest", label: "Jest", note: "fetch + jest globals" },
  { id: "supertest", label: "Supertest", note: "supertest client" },
];

function TestsPage() {
  const a = useAnalysis();
  const [framework, setFramework] = useState<TestFramework>("vitest");
  const [baseUrl, setBaseUrl] = useState("");
  const [code, setCode] = useState<string | null>(null);
  const [checked, setChecked] = useState<Set<number>>(new Set());

  if (!a.newSpec) return <EmptyState title="Upload the updated spec" body="Tests are generated from the new contract and the detected changes." to="/compare" cta="Compare specs" />;
  const defaultBase = a.newSpec.servers?.[0]?.url ?? "http://localhost:4000";
  const checklist = deploymentChecklist(a.changes, a.faults.length);

  return (
    <>
      <PageHeader eyebrow="Module 5 · Test generator" title="Regression Tests" description="Build an executable suite for every changed endpoint, plus checks that removed endpoints are really gone." />
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="min-w-0 space-y-4">
          <div className="panel flex flex-wrap items-end gap-4 p-5">
            <div>
              <p className="eyebrow mb-2 text-muted-foreground">Framework</p>
              <div className="flex gap-1 rounded-lg bg-muted p-1" role="radiogroup" aria-label="Test framework">
                {FRAMEWORKS.map((f) => (
                  <button key={f.id} role="radio" aria-checked={framework === f.id} onClick={() => setFramework(f.id)} className={cn("rounded-md px-3 py-1.5 text-sm transition-colors", framework === f.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
            <label className="min-w-[220px] flex-1">
              <span className="eyebrow mb-2 block text-muted-foreground">Base URL</span>
              <Input value={baseUrl} placeholder={defaultBase} onChange={(e) => setBaseUrl(e.target.value)} className="font-mono text-xs" />
            </label>
            <Button variant="signal" onClick={() => setCode(generateTests({ framework, baseUrl: baseUrl || defaultBase, endpoints: a.endpoints, changes: a.changes }))}>
              <FlaskConical /> Generate test suite
            </Button>
          </div>

          {code ? (
            <div>
              <div className="mb-2 flex items-center justify-between">
                <p className="font-mono text-xs text-muted-foreground">api-regression.spec.ts · {code.split("\n").length} lines · {(code.match(/\bit\(/g) ?? []).length} tests</p>
                <div className="flex gap-2">
                  <CopyButton text={code} />
                  <Button variant="panel" size="sm" onClick={() => downloadText("api-regression.spec.ts", code, "text/typescript")}>
                    <Download /> Download
                  </Button>
                </div>
              </div>
              <CodeBlock code={code} className="max-h-[640px]" />
            </div>
          ) : (
            <EmptyState title="Pick a framework and generate" body={`The suite will cover ${new Set(a.changes.map((c) => `${c.method} ${c.path}`)).size || a.endpoints.length} endpoints from ${a.newSpec.info?.title ?? "your API"}.`} />
          )}
        </div>

        <aside className="panel h-fit p-5">
          <h2 className="text-lg font-semibold">Pre-deployment checklist</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            {checked.size}/{checklist.length} done
          </p>
          <ul className="mt-4 space-y-3">
            {checklist.map((item, i) => (
              <li key={i}>
                <label className="flex cursor-pointer gap-3 text-sm">
                  <Checkbox
                    checked={checked.has(i)}
                    onCheckedChange={(v) =>
                      setChecked((prev) => {
                        const next = new Set(prev);
                        if (v) next.add(i);
                        else next.delete(i);
                        return next;
                      })
                    }
                    className="mt-0.5"
                  />
                  <span className={cn(checked.has(i) && "text-muted-foreground line-through")}>{item}</span>
                </label>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </>
  );
}
