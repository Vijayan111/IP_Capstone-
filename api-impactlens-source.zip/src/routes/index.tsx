import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, Circle, Plus, Sparkles, Trash2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState, PageHeader, StatCard } from "@/components/impact/ui";
import { RiskGauge } from "@/components/impact/RiskGauge";
import { specTitle } from "@/lib/analysis/openapi";
import { pageHead } from "@/lib/seo";
import { useWorkspace } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => pageHead("Overview", "See your API release at a glance: breaking changes, affected client files, faults and the overall risk score."),
  component: Overview,
});

function Overview() {
  const { ready, active, projects, createProject, createSampleProject, deleteProject, setActiveId } = useWorkspace();
  const a = useAnalysis();
  const [name, setName] = useState("");

  if (!ready) return <div className="h-64 animate-pulse rounded-xl bg-muted" />;

  const steps = [
    { done: Boolean(active?.oldSpec && active?.newSpec && a.hasSpecs), label: "Upload previous and updated OpenAPI specs", to: "/compare" },
    { done: Boolean(active?.source), label: "Scan the consuming client code", to: "/dependencies" },
    { done: a.faults.length === 0 ? Boolean(active?.source && a.hasSpecs) : false, label: a.faults.length ? `Patch ${a.faults.length} flagged call sites` : "Review faults & fixes", to: "/faults" },
    { done: false, label: "Generate regression tests and export the audit report", to: "/tests" },
  ];

  return (
    <>
      <PageHeader
        eyebrow="Release intelligence"
        title={active ? active.name : "Welcome to ImpactLens"}
        description={
          active && a.hasSpecs ? (
            <>
              <span className="font-mono text-foreground">{specTitle(a.oldSpec)}</span> → <span className="font-mono text-foreground">{specTitle(a.newSpec)}</span>
            </>
          ) : (
            "Catch breaking API changes before they reach the apps that depend on them."
          )
        }
        actions={
          <Button asChild variant="signal">
            <Link to="/compare">
              Compare specs <ArrowRight />
            </Link>
          </Button>
        }
      />

      {!active ? (
        <EmptyState title="Start your first project" body="Create a project below, or load the sample to see a full analysis in seconds." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[1.1fr_1.9fr]">
          <div className="panel flex flex-col items-center justify-center p-6">
            {a.risk ? (
              <>
                <RiskGauge score={a.risk.score} level={a.risk.level} />
                <Link to="/risk" className="mt-4 text-sm text-primary hover:underline">
                  See how this is calculated →
                </Link>
              </>
            ) : (
              <p className="py-10 text-center text-sm text-muted-foreground">Upload both specs to get a risk score.</p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <StatCard label="Breaking changes" value={a.breaking.length} hint={`${a.changes.length} changes in total`} tone={a.breaking.length ? "critical" : "low"} />
            <StatCard label="Client faults" value={a.faults.length} hint={`${a.faults.filter((f) => f.confidence === "confirmed").length} confirmed`} tone={a.faults.length ? "signal" : "default"} />
            <StatCard label="Files affected" value={a.risk?.blastRadius.files ?? 0} hint={`${a.source?.files.length ?? 0} files scanned`} />
            <StatCard label="API call sites" value={a.source?.references.length ?? 0} hint={`${new Set(a.source?.references.map((r) => r.path)).size} unique routes`} />
          </div>
        </div>
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="panel p-6">
          <h2 className="text-lg font-semibold">Release checklist</h2>
          <ol className="mt-4 space-y-2">
            {steps.map((s, i) => (
              <li key={i}>
                <Link to={s.to} className="flex items-center gap-3 rounded-md px-2 py-2 text-sm hover:bg-accent">
                  {s.done ? <CheckCircle2 className="size-4 text-sev-low" /> : <Circle className="size-4 text-muted-foreground" />}
                  <span className={cn(s.done && "text-muted-foreground line-through")}>{s.label}</span>
                  <ArrowRight className="ml-auto size-3.5 text-muted-foreground" />
                </Link>
              </li>
            ))}
          </ol>
        </section>

        <section className="panel p-6">
          <h2 className="text-lg font-semibold">Projects</h2>
          <form
            className="mt-4 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              createProject(name);
              setName("");
            }}
          >
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Payments API" aria-label="New project name" />
            <Button type="submit" variant="panel">
              <Plus /> Create
            </Button>
          </form>
          <ul className="mt-4 divide-y divide-border">
            {projects.map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-2.5">
                <button className={cn("flex-1 truncate text-left text-sm", p.id === active?.id ? "text-primary" : "hover:text-primary")} onClick={() => setActiveId(p.id)}>
                  {p.name}
                </button>
                <span className="font-mono text-[10px] uppercase text-muted-foreground">{p.oldSpec && p.newSpec ? "specs ✓" : "no specs"}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Delete ${p.name}`}
                  onClick={() => {
                    if (confirm(`Delete "${p.name}"? This can't be undone.`)) deleteProject(p.id);
                  }}
                >
                  <Trash2 />
                </Button>
              </li>
            ))}
          </ul>
          <Button variant="link" className="mt-2 px-0" onClick={() => createSampleProject()}>
            <Sparkles /> Load the sample project
          </Button>
        </section>
      </div>
    </>
  );
}
