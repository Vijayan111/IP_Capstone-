import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { Download, FolderOpen, PackageOpen, Sparkles } from "lucide-react";
import { lazy, Suspense, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EmptyState, MethodTag, PageHeader, StatCard, WorkspaceGate } from "@/components/impact/ui";
import { downloadBlob } from "@/lib/download";
import { SAMPLE_CLIENT_FILES } from "@/lib/samples";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";
import { buildZip, readFolder, readZip } from "@/lib/zip";

const DependencyGraph = lazy(() => import("@/components/impact/DependencyGraph"));

export const Route = createFileRoute("/dependencies")({
  head: () => pageHead("Dependency Map", "Scan JavaScript and TypeScript client code to map every API call to the services and components that make it."),
  component: () => (
    <WorkspaceGate>
      <DependenciesPage />
    </WorkspaceGate>
  ),
});

const LEGEND = [
  { label: "Endpoint", cls: "bg-info rounded-sm" },
  { label: "Breaking endpoint", cls: "bg-sev-critical rounded-sm" },
  { label: "Service / function", cls: "bg-primary rounded-full" },
  { label: "React component", cls: "bg-success rotate-45" },
  { label: "Hook", cls: "bg-sev-medium rotate-45" },
];

function DependenciesPage() {
  const { active, updateActive } = useWorkspace();
  const a = useAnalysis();
  const zipRef = useRef<HTMLInputElement>(null);
  const dirRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<string | null>(null);
  const brokenRefs = new Set(a.faults.map((f) => f.reference.id));

  const ingest = async (load: () => Promise<{ files: { path: string; content: string }[]; skipped: number; label: string }>) => {
    setBusy(true);
    try {
      const { files, skipped, label } = await load();
      if (!files.length) {
        toast.error("No JavaScript or TypeScript files found", { description: "Upload a folder or .zip containing .ts, .tsx, .js or .jsx files." });
        return;
      }
      updateActive({ source: { label, files } });
      toast.success(`Scanned ${files.length} files`, { description: skipped ? `${skipped} unsupported or unsafe files were skipped.` : undefined });
    } catch (e) {
      toast.error("Couldn't read that upload", { description: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const refs = a.source?.references ?? [];
  const shown = filter ? refs.filter((r) => r.symbol === filter || `${r.method} ${r.path}` === filter || r.file.endsWith(filter)) : refs;

  return (
    <>
      <PageHeader
        eyebrow="Module 2 · Source analysis"
        title="Dependency Map"
        description={active?.source ? <>Scanning <span className="font-mono text-foreground">{active.source.label}</span> — {active.source.files.length} files.</> : "Upload a client repository to find every fetch and Axios call."}
        actions={
          <>
            <input ref={zipRef} type="file" accept=".zip" className="hidden" aria-label="Upload source ZIP" onChange={(e) => { const f = e.target.files?.[0]; if (f) void ingest(async () => ({ ...(await readZip(f)), label: f.name })); e.target.value = ""; }} />
            <input ref={dirRef} type="file" className="hidden" aria-label="Select source folder" {...({ webkitdirectory: "", directory: "" } as Record<string, string>)} multiple onChange={(e) => { const l = e.target.files; if (l?.length) void ingest(() => readFolder(l)); e.target.value = ""; }} />
            <Button variant="signal" size="sm" disabled={busy} onClick={() => zipRef.current?.click()}>
              <PackageOpen /> Upload source ZIP
            </Button>
            <Button variant="panel" size="sm" disabled={busy} onClick={() => dirRef.current?.click()}>
              <FolderOpen /> Select folder
            </Button>
            <Button variant="ghost" size="sm" onClick={() => updateActive({ source: { label: "sample-client-app.zip", files: SAMPLE_CLIENT_FILES } })}>
              <Sparkles /> Sample
            </Button>
            <Button variant="ghost" size="sm" onClick={async () => downloadBlob("sample-client-app.zip", await buildZip(SAMPLE_CLIENT_FILES, "sample-client-app"))}>
              <Download /> Sample ZIP
            </Button>
          </>
        }
      />

      {!a.source ? (
        <EmptyState title="No client code scanned yet" body="Upload a .zip of your frontend or select its folder. Files stay in your browser — nothing is uploaded to a server." />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <StatCard label="Files scanned" value={a.source.files.length} hint={`${a.source.skipped.length} skipped`} />
            <StatCard label="API call sites" value={refs.length} />
            <StatCard label="Unique routes" value={new Set(refs.map((r) => `${r.method} ${r.path}`)).size} />
            <StatCard label="Broken call sites" value={brokenRefs.size} tone={brokenRefs.size ? "critical" : "low"} />
          </div>

          <div className="panel mt-4 overflow-hidden">
            <div className="flex flex-wrap items-center gap-4 border-b border-border px-4 py-3">
              {LEGEND.map((l) => (
                <span key={l.label} className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className={cn("inline-block size-2.5", l.cls)} /> {l.label}
                </span>
              ))}
              {filter && (
                <button className="ml-auto text-xs text-primary hover:underline" onClick={() => setFilter(null)}>
                  Clear filter “{filter}”
                </button>
              )}
            </div>
            {refs.length ? (
              <ClientOnly fallback={<div className="h-[560px] animate-pulse bg-muted/40" />}>
                <Suspense fallback={<div className="h-[560px] animate-pulse bg-muted/40" />}>
                  <DependencyGraph references={refs} usages={a.source.usages} faults={a.faults} onSelect={setFilter} />
                </Suspense>
              </ClientOnly>
            ) : (
              <p className="px-4 py-16 text-center text-sm text-muted-foreground">No fetch or Axios calls were found in these files.</p>
            )}
          </div>

          <div className="panel mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left">
                <tr className="eyebrow text-muted-foreground">
                  <th className="px-4 py-3 font-normal">Call</th>
                  <th className="px-4 py-3 font-normal">Location</th>
                  <th className="px-4 py-3 font-normal">Symbol</th>
                  <th className="px-4 py-3 font-normal">Via</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {shown.map((r) => (
                  <tr key={r.id} className={cn(brokenRefs.has(r.id) && "bg-sev-critical/5")}>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <MethodTag method={r.method} />
                        <span className="font-mono text-xs">{r.path}</span>
                        {brokenRefs.has(r.id) && <span className="font-mono text-[10px] uppercase text-sev-critical">breaks</span>}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">
                      {r.file}:{r.line}
                    </td>
                    <td className="px-4 py-2.5 text-xs">
                      {r.symbol} <span className="text-muted-foreground">({r.symbolKind})</span>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">{r.callType}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {(a.source.skipped.length > 0 || a.source.errors.length > 0) && (
            <details className="panel mt-4 p-4 text-sm">
              <summary className="cursor-pointer text-muted-foreground">
                {a.source.skipped.length} skipped · {a.source.errors.length} parse errors
              </summary>
              <ul className="mt-3 space-y-1 font-mono text-xs text-muted-foreground">
                {a.source.skipped.map((s) => (
                  <li key={s.path}>
                    {s.path} — {s.reason}
                  </li>
                ))}
                {a.source.errors.map((s) => (
                  <li key={s.path} className="text-destructive">
                    {s.path} — {s.message}
                  </li>
                ))}
              </ul>
            </details>
          )}
        </>
      )}
    </>
  );
}
