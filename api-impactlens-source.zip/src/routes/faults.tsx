import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CodeBlock, CopyButton, EmptyState, MethodTag, PageHeader, SeverityBadge, WorkspaceGate } from "@/components/impact/ui";
import { renderTicks } from "@/components/impact/ticks";
import { generateFix } from "@/lib/analysis/codeFixEngine";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/faults")({
  head: () => pageHead("Faults & Fixes", "See exactly which client call sites break and get before/after code, unified diffs and migration steps."),
  component: () => (
    <WorkspaceGate>
      <FaultsPage />
    </WorkspaceGate>
  ),
});

function FaultsPage() {
  const { active } = useWorkspace();
  const a = useAnalysis();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = a.faults.find((f) => f.id === selectedId) ?? a.faults[0] ?? null;
  const fix = useMemo(() => {
    if (!selected) return null;
    const content = active?.source?.files.find((f) => f.path === selected.reference.file)?.content ?? "";
    return generateFix(selected, content);
  }, [selected, active?.source]);

  if (!a.hasSpecs) return <EmptyState title="Upload both specs first" body="Faults are found by matching breaking changes against your client code." to="/compare" cta="Compare specs" />;
  if (!a.source) return <EmptyState title="Scan your client code" body="Upload the consuming app so ImpactLens can find the exact lines that will break." to="/dependencies" cta="Open Dependency Map" />;

  return (
    <>
      <PageHeader eyebrow="Module 4 · Fault detection" title="Faults & Fixes" description={`${a.faults.length} call sites are affected by breaking changes — ${a.faults.filter((f) => f.confidence === "confirmed").length} confirmed by field or parameter usage.`} />
      {!a.faults.length ? (
        <EmptyState title="No client faults" body="None of the scanned call sites hit a breaking change. Nice." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
          <ul className="panel max-h-[760px] divide-y divide-border overflow-y-auto">
            {a.faults.map((f) => (
              <li key={f.id}>
                <button onClick={() => setSelectedId(f.id)} className={cn("w-full px-4 py-3 text-left transition-colors hover:bg-accent", selected?.id === f.id && "bg-accent shadow-[inset_2px_0_0_var(--primary)]")}>
                  <div className="flex items-center gap-2">
                    <SeverityBadge severity={f.change.severity} />
                    <span className={cn("font-mono text-[10px] uppercase", f.confidence === "confirmed" ? "text-sev-critical" : "text-muted-foreground")}>{f.confidence}</span>
                  </div>
                  <p className="mt-1.5 truncate font-mono text-xs">
                    {f.reference.file}:{f.reference.line}
                  </p>
                  <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{f.change.description.replace(/`/g, "")}</p>
                </button>
              </li>
            ))}
          </ul>

          {selected && fix && (
            <div className="min-w-0 space-y-4">
              <div className="panel p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <MethodTag method={selected.change.method} />
                  <span className="font-mono text-sm">{selected.change.path}</span>
                  <SeverityBadge severity={selected.change.severity} />
                </div>
                <h2 className="mt-3 text-xl font-semibold">{renderTicks(fix.title)}</h2>
                <p className="mt-2 text-sm text-muted-foreground">{renderTicks(selected.message)}</p>
                <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 font-mono text-[11px] text-muted-foreground">
                  <span>
                    at <span className="text-foreground">{selected.reference.file}:{selected.reference.line}</span>
                  </span>
                  <span>
                    in <span className="text-foreground">{selected.reference.symbol}</span> ({selected.reference.symbolKind})
                  </span>
                  {selected.impactedCallers.length > 0 && <span>used by {selected.impactedCallers.map((u) => u.caller).join(", ")}</span>}
                </div>
              </div>

              <Tabs defaultValue="side">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <TabsList>
                    <TabsTrigger value="side">Before / After</TabsTrigger>
                    <TabsTrigger value="diff">Unified diff</TabsTrigger>
                    <TabsTrigger value="steps">Migration plan</TabsTrigger>
                  </TabsList>
                  <div className="flex gap-2">
                    <CopyButton text={fix.after} label="Copy fixed code" />
                    <CopyButton text={fix.diff} label="Copy diff" />
                  </div>
                </div>
                <TabsContent value="side" className="mt-3 grid gap-3 2xl:grid-cols-2">
                  <div>
                    <p className="eyebrow mb-1.5 text-diff-del">Before</p>
                    <CodeBlock code={fix.before} startLine={fix.startLine} highlight={selected.reference.line} />
                  </div>
                  <div>
                    <p className="eyebrow mb-1.5 text-diff-add">After</p>
                    <CodeBlock code={fix.after} startLine={fix.startLine} />
                  </div>
                </TabsContent>
                <TabsContent value="diff" className="mt-3">
                  <CodeBlock code={fix.diff} diff />
                </TabsContent>
                <TabsContent value="steps" className="mt-3">
                  <ol className="panel space-y-3 p-5">
                    {fix.steps.map((s, i) => (
                      <li key={i} className="flex gap-3 text-sm">
                        <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-primary font-mono text-[10px] text-primary-foreground">{i + 1}</span>
                        <span>{renderTicks(s)}</span>
                      </li>
                    ))}
                  </ol>
                </TabsContent>
              </Tabs>
              <p className="text-xs text-muted-foreground">
                Fixes are generated from rules based on the contract change. Review them before committing, then{" "}
                <Link to="/tests" className="text-primary hover:underline">
                  generate regression tests
                </Link>
                .
              </p>
            </div>
          )}
        </div>
      )}
    </>
  );
}
