import { createFileRoute } from "@tanstack/react-router";
import { Bot, Eraser, SendHorizontal } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader, WorkspaceGate } from "@/components/impact/ui";
import { renderTicks } from "@/components/impact/ticks";
import { answer, PROMPT_PILLS } from "@/lib/analysis/assistant";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { useWorkspace, type ChatMessage } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/assistant")({
  head: () => pageHead("Assistant", "Ask questions about your API release — risk, affected files, endpoints and fixes — with full project context."),
  component: () => (
    <WorkspaceGate>
      <AssistantPage />
    </WorkspaceGate>
  ),
});

function AssistantPage() {
  const { active, updateActive } = useWorkspace();
  const a = useAnalysis();
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const chat = active?.chat ?? [];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [chat.length, thinking]);

  const send = (text: string) => {
    const q = text.trim();
    if (!q || !active || thinking) return;
    const userMsg: ChatMessage = { role: "user", content: q, at: new Date().toISOString() };
    const history = [...chat, userMsg];
    updateActive({ chat: history });
    setInput("");
    setThinking(true);
    setTimeout(() => {
      const reply = answer(q, { projectName: active.name, changes: a.changes, faults: a.faults, risk: a.risk, source: a.source });
      updateActive({ chat: [...history, { role: "assistant", content: reply, at: new Date().toISOString() }] });
      setThinking(false);
    }, 350);
  };

  return (
    <>
      <PageHeader
        eyebrow="Module 7 · Assistant"
        title="Assistant"
        description={`Answers come from the analysis of “${active?.name}”: ${a.changes.length} changes, ${a.faults.length} faults.`}
        actions={
          chat.length > 0 && (
            <Button variant="ghost" size="sm" onClick={() => updateActive({ chat: [] })}>
              <Eraser /> Clear chat
            </Button>
          )
        }
      />
      <div className="panel flex h-[640px] flex-col overflow-hidden">
        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {chat.length === 0 && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="grid size-12 place-items-center rounded-full border border-primary/40 bg-primary/10">
                <Bot className="size-5 text-primary" />
              </div>
              <p className="mt-3 text-sm text-muted-foreground">Ask anything about this release, or pick a question below.</p>
            </div>
          )}
          {chat.map((m, i) => (
            <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
              <div className={cn("max-w-[85%] whitespace-pre-wrap rounded-xl px-4 py-3 text-sm leading-relaxed", m.role === "user" ? "bg-primary text-primary-foreground" : "border border-border bg-surface-raised")}>
                {m.role === "assistant" ? renderTicks(m.content) : m.content}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex gap-1 px-2" aria-label="Assistant is typing">
              {[0, 1, 2].map((i) => (
                <span key={i} className="size-1.5 animate-bounce rounded-full bg-primary" style={{ animationDelay: `${i * 120}ms` }} />
              ))}
            </div>
          )}
          <div ref={endRef} />
        </div>
        <div className="border-t border-border p-4">
          <div className="mb-3 flex flex-wrap gap-1.5">
            {PROMPT_PILLS.map((p) => (
              <button key={p} onClick={() => send(p)} className="rounded-full border border-border bg-surface px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary">
                {p}
              </button>
            ))}
          </div>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
          >
            <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="e.g. What changed on /users?" aria-label="Message" />
            <Button type="submit" variant="signal" disabled={!input.trim() || thinking}>
              <SendHorizontal /> Send
            </Button>
          </form>
        </div>
      </div>
    </>
  );
}
