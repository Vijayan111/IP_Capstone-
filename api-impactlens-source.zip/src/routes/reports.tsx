import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { CodeBlock, CopyButton, EmptyState, PageHeader, WorkspaceGate } from "@/components/impact/ui";
import { specTitle } from "@/lib/analysis/openapi";
import { generateReport, type ReportFormat } from "@/lib/analysis/reportGenerator";
import { downloadText } from "@/lib/download";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/lib/workspace-context";
import { useAnalysis } from "@/lib/use-analysis";

export const Route = createFileRoute("/reports")({
  head: () => pageHead("Reports", "Export an executive API audit report as Markdown, self-contained HTML or JSON."),
  component: () => (
    <WorkspaceGate>
      <ReportsPage />
    </WorkspaceGate>
  ),
});

const FORMATS: { id: ReportFormat; label: string; ext: string; mime: string }[] = [
  { id: "html", label: "HTML", ext: "html", mime: "text/html" },
  { id: "markdown", label: "Markdown", ext: "md", mime: "text/markdown" },
  { id: "json", label: "JSON", ext: "json", mime: "application/json" },
];

function ReportsPage() {
  const { active } = useWorkspace();
  const a = useAnalysis();
  const [format, setFormat] = useState<ReportFormat>("html");
  const report = useMemo(() => {
    if (!a.risk || !active) return null;
    return generateReport(
      {
        projectName: active.name,
        generatedAt: new Date().toLocaleString(),
        oldSpecTitle: specTitle(a.oldSpec),
        newSpecTitle: specTitle(a.newSpec),
        changes: a.changes,
        faults: a.faults,
        risk: a.risk,
        filesScanned: a.source?.files.length ?? 0,
        referencesFound: a.source?.references.length ?? 0,
      },
      format,
    );
  }, [a, active, format]);

  if (!report) return <EmptyState title="Nothing to report yet" body="Upload both specs to build an audit report." to="/compare" cta="Compare specs" />;
  const meta = FORMATS.find((f) => f.id === format)!;
  const slug = (active?.name ?? "api").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  return (
    <>
      <PageHeader
        eyebrow="Module 6 · Audit reports"
        title="Reports"
        description="Executive summary, breaking-change breakdown, blast radius and a remediation plan — ready to share."
        actions={
          <>
            <CopyButton text={report} />
            <Button variant="signal" size="sm" onClick={() => downloadText(`impactlens-${slug}.${meta.ext}`, report, meta.mime)}>
              <Download /> Export {meta.label}
            </Button>
          </>
        }
      />
      <div className="mb-4 flex gap-1 rounded-lg bg-muted p-1 sm:w-fit" role="radiogroup" aria-label="Report format">
        {FORMATS.map((f) => (
          <button key={f.id} role="radio" aria-checked={format === f.id} onClick={() => setFormat(f.id)} className={cn("flex-1 rounded-md px-4 py-1.5 text-sm transition-colors", format === f.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>
            {f.label}
          </button>
        ))}
      </div>
      {format === "html" ? (
        <div className="panel overflow-hidden">
          <iframe title="Report preview" srcDoc={report} sandbox="" className="h-[720px] w-full bg-foreground" />
        </div>
      ) : (
        <CodeBlock code={report} className="max-h-[720px]" />
      )}
    </>
  );
}
