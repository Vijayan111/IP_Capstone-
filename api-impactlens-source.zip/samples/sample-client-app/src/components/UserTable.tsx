import { useEffect, useState } from "react";
import { getUsers, deleteUser, type User } from "../services/userService";

export function UserTable() {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    getUsers(1).then(setUsers);
  }, []);

  return (
    <table>
      <tbody>
        {users.map((u) => (
          <tr key={u.id}>
            <td>{u.name}</td>
            <td>{u.email}</td>
            <td>
              <button onClick={() => deleteUser(u.id)}>Remove</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
