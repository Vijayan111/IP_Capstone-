import { useEffect, useState } from "react";
import { getPlans, type Plan } from "../services/plansService";

export function PricingPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  useEffect(() => {
    getPlans().then(setPlans);
  }, []);
  return (
    <section>
      {plans.map((plan) => (
        <article key={plan.id}>
          <h3>{plan.name}</h3>
          <p>${plan.price.toFixed(2)} / month</p>
        </article>
      ))}
    </section>
  );
}
