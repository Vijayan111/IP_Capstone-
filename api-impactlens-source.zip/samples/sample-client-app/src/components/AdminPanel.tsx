import { downloadLegacyReport } from "../services/billingService";
import { createUser } from "../services/userService";
import { useCurrentUser } from "../hooks/useCurrentUser";

export function AdminPanel({ userId }: { userId: string }) {
  const me = useCurrentUser(userId);
  if (me?.role !== "admin") return null;
  return (
    <div>
      <p>Signed in as {me.email}</p>
      <button onClick={() => createUser("New teammate", "new@example.com")}>Invite</button>
      <button onClick={downloadLegacyReport}>Export CSV</button>
    </div>
  );
}
