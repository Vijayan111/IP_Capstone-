import { useEffect, useState } from "react";
import { listInvoices, payInvoice } from "../services/billingService";

export function InvoiceList() {
  const [invoices, setInvoices] = useState<Awaited<ReturnType<typeof listInvoices>>>([]);

  useEffect(() => {
    listInvoices("open").then(setInvoices);
  }, []);

  return (
    <ul>
      {invoices.map((inv) => (
        <li key={inv.id}>
          {inv.label} — {inv.status}
          <button onClick={() => payInvoice(inv.id)}>Pay</button>
        </li>
      ))}
    </ul>
  );
}
