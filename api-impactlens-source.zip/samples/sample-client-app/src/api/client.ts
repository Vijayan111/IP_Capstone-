import axios from "axios";

export const BASE_URL = "https://api.example.com/v1";

export const api = axios.create({
  baseURL: BASE_URL,
  headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
});
