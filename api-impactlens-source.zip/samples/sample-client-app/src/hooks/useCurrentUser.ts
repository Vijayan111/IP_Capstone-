import { useEffect, useState } from "react";
import { getUser, type User } from "../services/userService";

export function useCurrentUser(id: string) {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    getUser(id).then(setUser);
  }, [id]);
  return user;
}
