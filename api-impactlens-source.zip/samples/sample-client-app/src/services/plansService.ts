export interface Plan {
  id: string;
  name: string;
  price: number;
}

export async function getPlans(): Promise<Plan[]> {
  const res = await fetch("https://api.example.com/v1/plans");
  return res.json();
}
