import { api } from "../api/client";

export type InvoiceStatus = "draft" | "open" | "paid" | "void";

export interface Invoice {
  id: string;
  amount: number;
  currency: string;
  status: InvoiceStatus;
}

export async function listInvoices(status?: InvoiceStatus) {
  const { data } = await api.get("/invoices", { params: { status } });
  return (data as Invoice[]).map((inv) => ({
    ...inv,
    label: `${inv.currency} ${inv.amount.toFixed(2)}`,
  }));
}

export async function payInvoice(id: string) {
  const res = await fetch(`/v1/invoices/${id}/pay`, { method: "POST" });
  return (await res.json()) as Invoice;
}

export async function downloadLegacyReport() {
  const res = await fetch("/v1/legacy/reports");
  const { url } = await res.json();
  window.location.assign(url);
}
