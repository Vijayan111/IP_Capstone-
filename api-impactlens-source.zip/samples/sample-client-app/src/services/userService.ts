import axios from "axios";
import { api } from "../api/client";

const BASE_URL = "https://api.example.com/v1";

export interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "member";
}

export async function getUsers(page = 1): Promise<User[]> {
  const res = await fetch(`${BASE_URL}/users?page=${page}`);
  const users = await res.json();
  return users.map((u: User) => ({ ...u, email: u.email.toLowerCase() }));
}

export async function getUser(id: string): Promise<User> {
  const { data } = await api.get(`/users/${id}`);
  return data;
}

export async function createUser(name: string, email: string) {
  const { data } = await axios.post(`${BASE_URL}/users`, { name, email });
  return data as User;
}

export async function deleteUser(id: string) {
  await api.delete(`/users/${id}`);
}
